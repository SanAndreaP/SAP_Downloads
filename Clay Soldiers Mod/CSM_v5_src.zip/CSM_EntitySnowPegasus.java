package net.minecraft.src;

public class CSM_EntitySnowPegasus extends CSM_EntityDirtHorse {
	
	public CSM_EntitySnowPegasus(World world) {
		super(world);
		health = 40;
		horseType = 0;
		texture = dirtHorseTexture(0);
		moveSpeed = 0.5F;
		sinage = rand.nextFloat();
	}
	
	public CSM_EntitySnowPegasus(World world, double x, double y, double z, int i) {
		super(world, x, y, z, i);
		texture = dirtHorseTexture(i);
		horseType = i;
		setHorseSpecs(i); /*ADDED*/
		/*REMOVED*/
//		if(i == 0) {
//			health = 30;
//			moveSpeed = 0.6f;
//		} else if(i == 1) {
//			health = 25;
//			moveSpeed = 0.7f;
//		} else if(i == 2) {
//			health = 40;
//			moveSpeed = 0.4f;
//		} else if(i == 3) {
//			health = 35;
//			moveSpeed = 0.5f;
//		} else if(i == 4) {
//			health = 15;
//			moveSpeed = 0.9f;
//		} else if(i == 5) {
//			health = 30;
//			moveSpeed = 0.9f;
//		} else if(i == 6) {
//			health = 30;
//			moveSpeed = 0.6f;
//		}
		sinage = rand.nextFloat();
	}

	public String dirtHorseTexture(int i) {
		String epona = "/claymans/horse";
		if(i == 0) {
			epona = epona + "Dirt";
		} else if(i == 1) {
			epona = epona + "Sand";
		} else if(i == 2) {
			epona = epona + "Gravel";
		} else if(i == 3) {
			epona = epona + "Snow";
		} else if(i == 4) {
			epona = epona + "Grass";
		} else if(i == 5) {
			epona = epona + "Lapis";
		} else if(i == 6) {
			epona = epona + "Clay";
		}
		return epona + ".png";
	}

	public void onUpdate() {
		super.onUpdate();
		
		if(!onGround) {
			sinage += 0.75F;
		} else {
			sinage += 0.15F;
		}
		
		if(sinage > 3.141593F * 2F) {
			sinage -= (3.141593F * 2F);
		}
	}
	
	protected void fall(float f) {
    }
	
	public void updateEntityActionState() {
		super.updateEntityActionState();
		
		boolean plunge = false;
		if(!onGround && riddenByEntity != null && riddenByEntity instanceof CSM_EntityClayMan) {
			CSM_EntityClayMan ec = (CSM_EntityClayMan)riddenByEntity;
			if(!ec.isDead) {
				if(ec.targetFollow != null) {
					double a = ec.posX - ec.targetFollow.posX;
					double b = ec.posZ - ec.targetFollow.posZ;
					double d = Math.sqrt((a * a) + (b * b));
					
					if(d <= 1.75D && ec.boundingBox.minY > (ec.targetFollow.posY - 1.0D)) {
						plunge = true;
					}
				} if(ec.entityToAttack != null) {
					double a = ec.posX - ec.entityToAttack.posX;
					double b = ec.posZ - ec.entityToAttack.posZ;
					double d = Math.sqrt((a * a) + (b * b));
					
					if(d <= 1.75D && ec.boundingBox.minY > (ec.entityToAttack.posY - 1.0D)) {
						plunge = true;
					}
				}
			}
		}
	
		if(riddenByEntity != null) {
			riddenByEntity.fallDistance = 0.0F;
			if(moveForward != 0.0F && !plunge) {
				if(onGround) {
					isJumping = true;
				} else {
					int j = MathHelper.floor_double(posX);
					int i1 = MathHelper.floor_double(boundingBox.minY);
					int k1 = MathHelper.floor_double(boundingBox.minY - 0.5D);
					int l1 = MathHelper.floor_double(posZ);
					if((worldObj.getBlockId(j, i1 - 1, l1) != 0 || worldObj.getBlockId(j, k1 - 1, l1) != 0) && worldObj.getBlockId(j, i1 + 2, l1) == 0 && worldObj.getBlockId(j, i1 + 1, l1) == 0) {
						motionY = 0.2D;
					}
				}
			}
		}
		
		if(!onGround && motionY < -0.1D) {
			motionY = -0.1D;
		}
    }
	
	protected void dropFewItems(boolean flag, int i) {
		Item item1 = mod_ClayMan.pegasusDoll;
		dropItem(item1.shiftedIndex, 1, horseType);
	}
	
	public boolean isOnLadder() {
		return isCollidedHorizontally && !onGround;
	}
	
	public int getMaxHealth() {
		switch (horseType) {
			case 0: return 35;
			case 1: return 30;
			case 2: return 45;
			case 3: return 40;
			case 4: return 20;
			case 5: return 35;
			case 6: return 35;
			default: return 45;
		}
	}

	public void writeToNBT(NBTTagCompound nbttagcompound)
    {
		super.writeToNBT(nbttagcompound);
		gotRider = (riddenByEntity == null);
		nbttagcompound.setBoolean("GotRider", gotRider);
		nbttagcompound.setShort("HorseType", (short)horseType);
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound)
    {
		super.readFromNBT(nbttagcompound);
		gotRider = nbttagcompound.getBoolean("GotRider");
		if(nbttagcompound.hasKey("HorseType"))
			horseType = (short)nbttagcompound.getShort("HorseType");
		texture = dirtHorseTexture(horseType);
		setHorseSpecs(horseType);/*ADDED*/
	}
	
	public float sinage;
	public int horseType;
}