package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class CSM_RenderSnowPegasus extends CSM_RenderDirtHorse {

    public CSM_RenderSnowPegasus(ModelBiped model, float f) {
        super(model, f);
		mv1 = (CSM_ModelSnowPegasus)model;
    }
	
	protected void preRenderCallback(EntityLiving entityliving, float f) {
		super.preRenderCallback(entityliving, f);
		CSM_EntitySnowPegasus v1 = (CSM_EntitySnowPegasus)entityliving;
		mv1.sinage = v1.sinage;
		mv1.gonRound = v1.onGround;
    }
	
	public CSM_ModelSnowPegasus mv1;
}