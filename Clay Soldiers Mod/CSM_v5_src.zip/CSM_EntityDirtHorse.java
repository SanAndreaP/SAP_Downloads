package net.minecraft.src;

import java.util.List;

public class CSM_EntityDirtHorse extends EntityCreature {
	
	public CSM_EntityDirtHorse(World world) {
		super(world);
		health = 30;
		horseType = 0;
		yOffset = 0.0F;
		stepHeight = 0.1F;
		moveSpeed = 0.6F; 
		setSize(0.25F, 0.4F);
		setPosition(posX, posY, posZ);
		texture = dirtHorseTexture(0);
		renderDistanceWeight = 5D;
	}
	
	public CSM_EntityDirtHorse(World world, double x, double y, double z, int i) {
		super(world);
		health = 30;
		horseType = i;
		yOffset = 0.0F;
		stepHeight = 0.1F;
		moveSpeed = 0.6F;
		setSize(0.25F, 0.4F);
		setPosition(x, y, z);
		texture = dirtHorseTexture(i);
		setHorseSpecs(i);/*ADDED*/
		/*REMOVED*/
//		if(i == 0) {
//			health = 30;
//			moveSpeed = 0.6f;
//		} else if(i == 1) {
//			health = 25;
//			moveSpeed = 0.7f;
//		} else if(i == 2) {
//			health = 40;
//			moveSpeed = 0.4f;
//		} else if(i == 3) {
//			health = 35;
//			moveSpeed = 0.5f;
//		} else if(i == 4) {
//			health = 15;
//			moveSpeed = 0.9f;
//		} else if(i == 5) {
//			health = 30;
//			moveSpeed = 0.9f;
//		} else if(i == 6) {
//			health = 30;
//			moveSpeed = 0.6f;
//		}
		renderDistanceWeight = 5D;
		worldObj.playSoundAtEntity(this, "step.gravel", 0.8F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) * 0.9F);
	}

	public String dirtHorseTexture(int i) {
		String epona = "/claymans/horse";
		if(i == 0) {
			epona = epona + "Dirt";
		} else if(i == 1) {
			epona = epona + "Sand";
		} else if(i == 2) {
			epona = epona + "Gravel";
		} else if(i == 3) {
			epona = epona + "Snow";
		} else if(i == 4) {
			epona = epona + "Grass";
		} else if(i == 5) {
			epona = epona + "Lapis";
		} else if(i == 6) {
			epona = epona + "Clay";
		}
		return epona + ".png";
	}
	
	public void onUpdate() {
        super.onUpdate();

        if(gotRider) {
            if(riddenByEntity != null) {
				gotRider = false;
                return;
            }

            List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(0.1D, 0.1D, 0.1D));

            for(int i = 0; i < list.size(); i++) {
                Entity entity = (Entity)list.get(i);

                if(!(entity instanceof CSM_EntityClayMan)) {
                    continue;
                }

                EntityLiving entityliving = (EntityLiving)entity;

                if(entityliving.ridingEntity != null || entityliving.riddenByEntity == this) {
                    continue;
                }

                entity.mountEntity(this);
                break;
            }

            gotRider = false;
        }
    }
	
	public void updateEntityActionState() {
		if(riddenByEntity == null || !(riddenByEntity instanceof CSM_EntityClayMan)) {
			super.updateEntityActionState();
		} else {
			CSM_EntityClayMan rider = (CSM_EntityClayMan)riddenByEntity;
			isJumping = rider.isJumping || handleWaterMovement();
			moveForward = rider.moveForward * (rider.sugarTime > 0 ? 1F : 2F);
			moveStrafing = rider.moveStrafing * (rider.sugarTime > 0 ? 1F : 2F);
			rotationYaw = prevRotationYaw = rider.rotationYaw;
			rotationPitch = prevRotationPitch = rider.rotationPitch;
			// if(rider.hasPath()) {
				// setPathToEntity(rider.getPathToEntity());
			// }
			rider.renderYawOffset = renderYawOffset;
			riddenByEntity.fallDistance = 0.0F;
			
			if(rider.isDead || rider.health <= 0) {
				rider.mountEntity(null);
			}
		}
	}
	
	public void moveEntityWithHeading(float f, float f1)
    {
		super.moveEntityWithHeading(f, f1);
		double d2 = (posX - prevPosX) * 2.0F;
        double d3 = (posZ - prevPosZ) * 2.0F;
		float f5 = MathHelper.sqrt_double(d2 * d2 + d3 * d3) * 4F;
        if(f5 > 1.0F)
        {
            f5 = 1.0F;
        }
        field_704_R += (f5 - field_704_R) * 0.4F;
        field_703_S += field_704_R;
	}
	
	public void setHorseSpecs(int i) { /*ADDED*/
		if(i == 0) {
			health = 35;
			moveSpeed = 0.6f;
		} else if(i == 1) {
			health = 30;
			moveSpeed = 0.7f;
		} else if(i == 2) {
			health = 45;
			moveSpeed = 0.4f;
		} else if(i == 3) {
			health = 40;
			moveSpeed = 0.5f;
		} else if(i == 4) {
			health = 20;
			moveSpeed = 0.9f;
		} else if(i == 5) {
			health = 35;
			moveSpeed = 0.9f;
		} else if(i == 6) {
			health = 35;
			moveSpeed = 0.6f;
		}
	}
	
	public void writeToNBT(NBTTagCompound nbttagcompound)
    {
		super.writeToNBT(nbttagcompound);
		gotRider = (riddenByEntity == null);
		nbttagcompound.setBoolean("GotRider", gotRider);
		nbttagcompound.setShort("HorseType", (short)horseType);
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound)
    {
		super.readFromNBT(nbttagcompound);
		gotRider = nbttagcompound.getBoolean("GotRider");
		if(nbttagcompound.hasKey("HorseType"))
			horseType = (int)nbttagcompound.getShort("HorseType"/*CHANGED*/);
		texture = dirtHorseTexture(horseType);
		setHorseSpecs(horseType);/*ADDED*/
	}
	
	protected String getHurtSound()
    {
		worldObj.playSoundAtEntity(this, "step.gravel", 0.6F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		return "";
    }
	
	protected String getDeathSound()
    {
		return "step.gravel";
    }
	
	protected void jump()
    {
		motionY = 0.4D;
    }
	
	public void mountEntity(Entity e) {
		if(!(e != null && e instanceof EntityMinecart)) {
			super.mountEntity(e);
		}
	}
	
	protected boolean canDespawn()
    {
        return false;
    }
	
	protected void dropFewItems(boolean flag, int i) {
		Item item1 = mod_ClayMan.horseDoll;
		dropItem(item1.shiftedIndex, 1, horseType);
	}
	
	protected void dropItem(int shiftedIndex, int i, int j) {
		// TODO Auto-generated method stub
		entityDropItem(new ItemStack(shiftedIndex, i, j), 0.0F);
	}

	public boolean attackEntityFrom(DamageSource damagesource, int i) {
		Entity e = damagesource.getSourceOfDamage();
		if(e == null || !(e instanceof CSM_EntityClayMan)) {
			i = 100;
		}
		boolean fred = super.attackEntityFrom(damagesource, i);
		if(fred && health <= 0) {
			Item item1 = mod_ClayMan.horseDoll;
			for(int j = 0; j < 4; j++) {
				double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
				double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
				double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
				ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.dirt, 0, 0)));
			}
			isDead = true;
		}
		return fred;
	}
	
	public void knockBack(Entity entity, int i, double d, double d1)
    {
        super.knockBack(entity, i, d, d1);
		if(entity != null && entity instanceof CSM_EntityClayMan) {
			motionX *= 0.6D;
			motionY *= 0.75D;
			motionZ *= 0.6D;
		}
    }
	
	public boolean isOnLadder() {
		return false;
    }
	
	public boolean interact(EntityPlayer e) {
		return false;
	}
	
	protected EntityAnimal func_40145_a(EntityAnimal entityanimal) {
		return new EntityPig(worldObj);
	}
	
	public int getMaxHealth() {
		switch (horseType) {
			case 0: return 30;
			case 1: return 25;
			case 2: return 40;
			case 3: return 35;
			case 4: return 15;
			case 5: return 30;
			case 6: return 30;
			default: return 40;
		}
	}
	
	public boolean gotRider;
	public int horseType;
}