package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class CSM_RenderClayMan extends RenderBiped {

    public CSM_RenderClayMan(ModelBiped model, float f) {
        super(model, f);
		mc1 = (CSM_ModelClayMan)model;
		setRenderPassModel(model);
    }
	
	protected int clayGlow(CSM_EntityClayMan clayman, int i, float f) {
        if(i != 0 || !clayman.isGlowing()) {
            return -1;
        } else {
            float f1 = 1.0F;
            GL11.glEnable(3042 /*GL_BLEND*/);
            GL11.glDisable(3008 /*GL_ALPHA_TEST*/);
            GL11.glBlendFunc(1, 1);
            int j = 61680;
            int k = j % 0x10000;
            int l = j / 0x10000;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapEnabled, (float)k / 1.0F, (float)l / 1.0F);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, f1);
            return 1;
        }
    }
	
	protected int shouldRenderPass(EntityLiving entityliving, int i, float f)
    {
        return clayGlow((CSM_EntityClayMan)entityliving, i, f);
    }
	
	protected void preRenderCallback(EntityLiving entityliving, float f) {
        CSM_EntityClayMan c1 = (CSM_EntityClayMan)entityliving;
		mc1.hasStick = c1.hasStick();
		mc1.hasBlazeRod = c1.hasBlazeRod();
		mc1.hasSpecks = c1.hasSpecks();
		mc1.hasArmor = c1.hasArmor();
		mc1.hasCrown = c1.hasCrown();
		mc1.isPadded = c1.isPadded();
		mc1.isSharpened = c1.isSharpened();
		mc1.isGooey = c1.isGooey();
		mc1.hasLogs = c1.hasLogs();
		mc1.holdFeather = c1.holdFeather();
		mc1.hasRocks = c1.hasRocks();
		mc1.hasGoggles = c1.hasGoggles();
		mc1.armLeft = c1.armLeft();
		mc1.isSuper = c1.isSuper();
		if(mc1.isSuper) {
			mc1.capeSwing = c1.capeSwing();
		}
		
		boolean flag = false;
		if(c1.isOnLadder()) {
			c1.climbTime ++;
			flag = true;
		}
		
		mc1.isClimbing = flag;
		
		GL11.glScalef(0.6F, 0.6F, 0.6F);
		if(c1.isCorrupt() && !c1.isGlowing()) {
			int i, j, k;
			i = (int)MathHelper.floor_double(c1.posX);
			j = (int)MathHelper.floor_double(c1.posY);
			k = (int)MathHelper.floor_double(c1.posZ);
			float lightness = (float)c1.worldObj.getFullBlockLightValue(i, j, k);
			if(c1.hurtTime > 0 || c1.deathTime > 0) {
				GL11.glColor3f((lightness / 20F) + 0.5F, 0.2F, 0.2F);
			} else {
				GL11.glColor3f(lightness / 35F, lightness / 35F, lightness / 35F);
			}
		}
		
		if(c1.holdFeather()) {
			ItemStack itemstack = new ItemStack(Item.feather.shiftedIndex, 1, 0);
			GL11.glPushMatrix();
			
                float f5 = 0.625F;

				GL11.glTranslatef(0F, -1.0F, 0F);
                GL11.glScalef(f5, f5, f5);

				GL11.glTranslatef(0.625F, 0.1F, -0.4F);
				GL11.glRotatef(90F, 0F, 0F, 1F);
				GL11.glRotatef(45F, 0F, 1F, 0F);
				
            renderManager.itemRenderer.renderItem(entityliving, itemstack, 0);
            GL11.glPopMatrix();
		}
    }

    protected void renderEquippedItems(EntityLiving entityliving, float f)
    {
        renderEquipped((CSM_EntityClayMan)entityliving, f);
    }
	
	protected void renderEquipped(CSM_EntityClayMan entitycm, float f)
    {
    	super.renderEquippedItems(entitycm, f);
        if(entitycm.hasBlazeRod()) {
	        ItemStack itemstack = new ItemStack(Item.blazeRod);
	        if(itemstack != null)
	        {
	            GL11.glPushMatrix();
	            mc1.bipedRightArm.postRender(0.0625F);
	            GL11.glTranslatef(-0.0625F, 0.4375F, 0.0625F);
	            
	                float f4 = 0.175F;
	                GL11.glTranslatef(0.05F, -0.15F, -0.08F);
	                GL11.glScalef(f4+0.2F, f4, f4);
	                GL11.glRotatef(140F, 0.0F, 0.0F, 1.0F);
	                GL11.glRotatef(-90F, 1.0F, 0.0F, 0.0F);
	                GL11.glRotatef(0F, 0.0F, 0.0F, 1.0F);
	                
	            renderManager.itemRenderer.renderItem(entitycm, itemstack, 0);
	            GL11.glPopMatrix();
	        }
        }
        if(entitycm.shieldPts > 0) {
	        ItemStack itemstack = new ItemStack(Block.blocksList[63]);
	        if(itemstack != null)
	        {
	            GL11.glPushMatrix();
	            mc1.bipedLeftArm.postRender(0.0625F);
	            GL11.glTranslatef(-0.0625F, 0.4375F, -0.0525F);
	                float f4 = 0.175F;
	                GL11.glTranslatef(0.05F, -0.15F, -0.08F);
	                GL11.glScalef(f4, f4, f4);
	                GL11.glRotatef(100F, 0.0F, 0.0F, 1.0F);
	                GL11.glRotatef(40F, 1.0F, 0.0F, 0.0F);
	                GL11.glRotatef(80F, 0.0F, 0.0F, 1.0F);
	                
	            renderManager.itemRenderer.renderItem(entitycm, itemstack, 0);
	            GL11.glPopMatrix();
	        }
        }
    }
	
	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		f1 *= 2F;
		super.doRenderLiving(entityliving, d, d1, d2, f, f1);
    }
	
	public CSM_ModelClayMan mc1;
}