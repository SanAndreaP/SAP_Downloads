package net.minecraft.src;

public class CSM_ModelSnowPegasus extends CSM_ModelDirtHorse
{

    public CSM_ModelSnowPegasus()
    {
        this(0.0F);
    }

    public CSM_ModelSnowPegasus(float f)
    {
        this(f, 0.0F);
    }

    public CSM_ModelSnowPegasus(float f, float f1)
    {
        super(f, f1);
		
		wingRight = new ModelRenderer(this, 0, 22);
		wingRight.mirror = true;
		wingRight.addBox(-0.5F, 0.25F, -2.25F, 13, 1, 5, f);
		wingRight.setRotationPoint(1.5F, -0.5F + f1, 0F);
		
		wingLeft = new ModelRenderer(this, 0, 22);
		wingLeft.addBox(-12.5F, 0.25F, -2.25F, 13, 1, 5, f);
		wingLeft.setRotationPoint(-1.5F, -0.5F + f1, 0F);
    }

    public void render(Entity e, float f, float f1, float f2, float f3, float f4, float f5)
    {
        super.render(e, f, f1, f2, f3, f4, f5);
		wingLeft.render(f5);
		wingRight.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5)
    {
		super.setRotationAngles(f, f1, f2, f3, f4, f5);
		
		wingLeft.rotateAngleY = -0.2F;
		wingRight.rotateAngleY = 0.2F;
		wingLeft.rotateAngleZ = -0.125F;
		wingRight.rotateAngleZ = 0.125F;
		
		wingLeft.rotateAngleY += Math.sin(sinage) / 6F;
		wingRight.rotateAngleY -= Math.sin(sinage) / 6F;
		wingLeft.rotateAngleZ += Math.cos(sinage) / (gonRound ? 8F : 3F);
		wingRight.rotateAngleZ -= Math.cos(sinage) / (gonRound ? 8F : 3F);
    }
	
	public ModelRenderer wingLeft, wingRight;
	
	public float sinage;
	public boolean gonRound;
}
