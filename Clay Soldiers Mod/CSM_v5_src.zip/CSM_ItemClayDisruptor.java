package net.minecraft.src;

import java.util.Random;
import java.util.List;

public class CSM_ItemClayDisruptor extends Item
{

    public CSM_ItemClayDisruptor(int i)
    {
        super(i);
        setMaxDamage(16);
        setMaxStackSize(1);
    }

    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        if(mod_ClayMan.waveTime <= 0)
        {
            itemstack.damageItem(1, entityplayer);
            mod_ClayMan.waveTime = 100;
			world.playSoundAtEntity(entityplayer, "portal.trigger", 1.5F, (itemRand.nextFloat() * 0.2F) + 1.4F);
			entityplayer.timeInPortal = 1.5F;
			entityplayer.prevTimeInPortal = 1.5F;
			
			List list1 = world.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(16D, 16D, 16D));

            for(int k = 0; k < list1.size(); k++) {
                Entity entity1 = (Entity)list1.get(k);
				if(entity1 instanceof CSM_EntityClayMan) {
					entity1.attackEntityFrom(DamageSource.causePlayerDamage(entityplayer), 100);
				} else if(entity1 instanceof CSM_EntityDirtHorse) {
					entity1.attackEntityFrom(DamageSource.causePlayerDamage(entityplayer), 100);
				}
			}
			
			int x = MathHelper.floor_double(entityplayer.posX);
			int y = MathHelper.floor_double(entityplayer.boundingBox.minY);
			int z = MathHelper.floor_double(entityplayer.posZ);
		
			for(int i = -12; i < 13; i++) {
				for(int j = -12; j < 13; j++) {
					for(int k = -12; k < 13; k++) {
						if(j + y <= 0 || j  + y >= 127) {
							continue;
						}
						
						if(world.getBlockId(x + i, y + j, z + k) != Block.blockClay.blockID) {
							continue;
						}
						
						double a = (double)i;
						double b = (double)j;
						double c = (double)k;
						if(Math.sqrt((a*a) + (b*b) + (c*c)) <= 12D) {
							blockCrush(world, x + i, y + j, z + k);
						}
					}
				}
			}
			
			for(int i = 0; i < 128; i++) {
				double angle = (double) i / 3D;
				double distance = 0.5D + ((double)i / 6D);
				double d = Math.sin(angle) * 0.25D;
				double f = Math.cos(angle) * 0.25D;
				double a = entityplayer.posX + (d * distance);
				double b = entityplayer.boundingBox.minY + 0.5D;
				double c = entityplayer.posZ + (f * distance);
				world.spawnParticle("portal", a, b, c, d, 0.0D, f);
			}
        }
        return itemstack;
    }
	
	public void blockCrush(World worldObj, int x, int y, int z) {
		int a = worldObj.getBlockId(x, y, z);
		int b = worldObj.getBlockMetadata(x, y, z);
		if(a == 0) {
			return;
		}
		ModLoader.getMinecraftInstance().effectRenderer.addBlockDestroyEffects(x, y, z, a, b);
		Block.blocksList[a].onBlockRemoval(worldObj, x, y, z);
		Block.blocksList[a].dropBlockAsItem(worldObj, x, y, z, b, 0);
		worldObj.setBlockWithNotify(x, y, z, 0);
	}
}
