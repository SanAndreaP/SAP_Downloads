package net.minecraft.src;

import java.util.Map;
import java.util.List;
import net.minecraft.client.Minecraft;

public class mod_ClayMan extends BaseMod {

	public String getVersion() {
        return "1.1.0 v.5";
    }

	/*CHANGED*/
	public static Item clayDisruptor;
	public static Item greyDoll;
	public static Item horseDoll;
	public static Item pegasusDoll;
	public static Item brickDoll; /*ADDED*/
	
    public static String modName = "ClaySoldierMod";

    public mod_ClayMan() {
		
    }

	public void load() {
		ModLoader.SetInGameHook(this, true, true);
		
		clayDisruptor = (new CSM_ItemClayDisruptor(6849)).setItemName("claydisruptor");
		greyDoll = (new CSM_ItemClayMan(6850, 0)).setItemName("claydoll");
		horseDoll = (new CSM_ItemDirtHorse(6851, 0)).setItemName("horsedoll");
		pegasusDoll = (new CSM_ItemDirtHorse(6852, 1)).setItemName("pegasusdoll");
		brickDoll = (new Item(6853)).setItemName("brickDoll");
		
		clayDisruptor.setIconIndex(ModLoader.addOverride("/gui/items.png", "/claymans/disruptor.png"));
		greyDoll.setIconIndex(ModLoader.addOverride("/gui/items.png", "/claymans/doll.png"));
		horseDoll.setIconIndex(ModLoader.addOverride("/gui/items.png", "/claymans/dollHorse.png"));
		pegasusDoll.setIconIndex(ModLoader.addOverride("/gui/items.png", "/claymans/dollPegasus.png"));
		brickDoll.setIconIndex(ModLoader.addOverride("/gui/items.png", "/claymans/dollBrick.png"));
		
		ModLoader.AddName(clayDisruptor, "Clay Disruptor");
		ModLoader.AddName(brickDoll, "Lifeless Brick Doll");
		
		String soldierNames[] = new String[] {"Clay Soldier", "Red Soldier", "Yellow Soldier", "Green Soldier", "Blue Soldier", "Orange Soldier", "Purple Soldier", "Pink Soldier", "Brown Soldier", "White Soldier", "Black Soldier"};
		String horseNames[] = new String[] {"Dirt Horse", "Sand Horse", "Gravel Horse", "Snow Horse", "Grass Horse", "Lapis Horse", "Clay Horse"};
		String pegasiNames[] = new String[] {"Dirt Pegasus", "Sand Pegasus", "Gravel Pegasus", "Snow Pegasus", "Grass Pegasus", "Lapis Pegasus", "Clay Pegasus"};
		
        for(int i = 0; i < soldierNames.length; i++)
        	ModLoader.AddName(new ItemStack(greyDoll, 1, i), soldierNames[i]);
        for(int i = 0; i < horseNames.length; i++)
        	ModLoader.AddName(new ItemStack(horseDoll, 1, i), horseNames[i]);
        for(int i = 0; i < pegasiNames.length; i++)
        	ModLoader.AddName(new ItemStack(pegasusDoll, 1, i), pegasiNames[i]);
		
		ModLoader.RegisterEntityID(CSM_EntityClayMan.class, "ClaySoldier", ModLoader.getUniqueEntityId());
		ModLoader.RegisterEntityID(CSM_EntityDirtHorse.class, "DirtHorse", ModLoader.getUniqueEntityId());
		ModLoader.RegisterEntityID(CSM_EntityGravelChunk.class, "GravelChunk", ModLoader.getUniqueEntityId());
		ModLoader.RegisterEntityID(CSM_EntitySnowPegasus.class, "SnowPegasus", ModLoader.getUniqueEntityId());
		
		 ModLoader.RegisterEntityID(CSM_Red.class, "CsmRed", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Yellow.class, "CsmYellow", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Green.class, "CsmGreen", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Blue.class, "CsmBlue", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Orange.class, "CsmOrange", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Purple.class, "CsmPurple", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Pink.class, "CsmPink", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Brown.class, "CsmBrown", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_White.class, "CsmWhite", ModLoader.getUniqueEntityId());
		 ModLoader.RegisterEntityID(CSM_Black.class, "CsmBlack", ModLoader.getUniqueEntityId());
		
		ModLoader.AddRecipe(new ItemStack(greyDoll, 4, 0), new Object[] {
			"$",
			"#",
			'$', Block.slowSand,
			'#', Block.blockClay
		});
		
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 0), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.dirt
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 1), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.sand
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 2), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.gravel
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 3), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockSnow
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 4), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.tallGrass
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 5), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockLapis
		});
		ModLoader.AddRecipe(new ItemStack(horseDoll, 2, 6), new Object[] {
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockClay
		});
		
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 0), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.dirt,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 1), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.sand,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 2), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.gravel,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 3), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockSnow,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 4), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.tallGrass,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 5), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockLapis,
			'@', Item.feather
		});
		ModLoader.AddRecipe(new ItemStack(pegasusDoll, 2, 6), new Object[] {
			" @ ",
			"#$#",
			"# #",
			'$', Block.slowSand,
			'#', Block.blockClay,
			'@', Item.feather
		});
		
//		ModLoader.AddRecipe(new ItemStack(greyDoll, 16, 0), new Object[] {
//			"##",
//			" #",
//			'#', Block.dirt
//		});

		ModLoader.AddRecipe(new ItemStack(clayDisruptor, 1, 0), new Object[] {
			"#$#",
			"#@#",
			'$', Item.stick,
			'#', Item.clay,
			'@', Item.redstone
		});
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 1), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 1)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 2), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 11)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 3), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 2)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 4), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 4)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 5), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 14)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 6), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 5)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 7), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 9)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 8), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 3)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 9), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 15)
        });
		
		ModLoader.AddShapelessRecipe(new ItemStack(greyDoll, 1, 10), new Object[] {
            new ItemStack(greyDoll, 1), new ItemStack(Item.dyePowder, 1, 0)
        });
	}
	
	public boolean OnTickInGame(float f, Minecraft game) {
		if(waveTime > 0) {
			waveTime --;
		}
		
		if(placeholder != null) {
			game.gameSettings.hideGUI = true;
			game.gameSettings.thirdPersonView = 0;
			if(placeholder.isSneaking()) {
				cameraReset(game);
			} else if(game.renderViewEntity instanceof EntityPlayerSP && !(game.renderViewEntity instanceof CSM_EntityClayCam)) {
				placeholder = (EntityPlayerSP)game.renderViewEntity;
				cameraReset(game);
			}
		}
		return true;
	}
	
	public static void cameraReset() {
		cameraReset(ModLoader.getMinecraftInstance());
	}
	
	public static void cameraReset(Minecraft game) {
		if(placeholder != null) {
			game.renderViewEntity = placeholder;
			placeholder = null;
			game.gameSettings.hideGUI = showTheHUD;
			game.gameSettings.thirdPersonView = (showTheGUY ? 0 : 1);
			claycam.setEntityDead();
			int cnt = game.theWorld.playerEntities.size();
			for(int i = 0; i < cnt; i++) {
				if(game.theWorld.playerEntities.get(i).equals(claycam))
					game.theWorld.playerEntities.remove(i);
			}
			claycam = null;
		}
	}
	
    public void AddRenderer(Map map) {
        map.put(CSM_EntityClayMan.class, new CSM_RenderClayMan(new CSM_ModelClayMan(0F, 13F), 0.125F));
		map.put(CSM_EntityDirtHorse.class, new CSM_RenderDirtHorse(new CSM_ModelDirtHorse(0F, 12.75F), 0.15F));
		map.put(CSM_EntityGravelChunk.class, new CSM_RenderGravelChunk());
		map.put(CSM_EntitySnowPegasus.class, new CSM_RenderSnowPegasus(new CSM_ModelSnowPegasus(0F, 12.75F), 0.15F));
    }

	public static EntityPlayer placeholder;
	public static CSM_EntityClayCam claycam;
	public static int waveTime;
	public static boolean showTheHUD, showTheGUY;
}
