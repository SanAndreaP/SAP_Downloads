package net.minecraft.src;

public class CSM_Black extends CSM_EntityClayMan{
	public CSM_Black(World world) {
		super(world, 0D, 0D, 0D, 10);
	}
}