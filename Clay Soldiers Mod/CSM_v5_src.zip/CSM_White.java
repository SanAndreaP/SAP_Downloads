package net.minecraft.src;

public class CSM_White extends CSM_EntityClayMan{
	public CSM_White(World world) {
		super(world, 0D, 0D, 0D, 9);
	}
}