package net.minecraft.src;

import java.util.List;
import net.minecraft.client.Minecraft;

public class CSM_EntityClayMan extends EntityCreature {
	
	public CSM_EntityClayMan(World world) {
		super(world);
		health = 20;
		clayTeam = 0;
		yOffset = 0.0F;
		stepHeight = 0.1F;
		moveSpeed = 0.3F;
		setSize(0.15F, 0.4F);
		setPosition(posX, posY, posZ);
		texture = clayManTexture(0);
		renderDistanceWeight = 5D;
	}
	
	public CSM_EntityClayMan(World world, double x, double y, double z, int i) {
		super(world);
		health = 20;
		clayTeam = i;
		yOffset = 0.0F;
		stepHeight = 0.1F;
		moveSpeed = 0.3F;
		setSize(0.15F, 0.4F);
		setPosition(x, y, z);
		texture = clayManTexture(i);
		if(i == 9) {
			health = 15;
		} else if(i == 10) {
			health = 30;
		}
		renderDistanceWeight = 5D;
		worldObj.playSoundAtEntity(this, "step.gravel", 0.8F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) * 0.9F);
	}
	
	public String clayManTexture(int i) {
		String joe = "/claymans/clay";
		if(i == 0) {
			joe = joe + "Grey";
		} else if(i == 1) {
			joe = joe + "Red";
		} else if(i == 2) {
			joe = joe + "Yellow";
		} else if(i == 3) {
			joe = joe + "Green";
		} else if(i == 4) {
			joe = joe + "Blue";
		} else if(i == 5) {
			joe = joe + "Orange";
		} else if(i == 6) {
			joe = joe + "Purple";
		} else if(i == 7) {
			joe = joe + "Pink";
		} else if(i == 8) {
			joe = joe + "Brown";
		} else if(i == 9) {
			joe = joe + "White";
		} else {
			joe = joe + "Black";
		}
		return joe + ".png";
	}
	
	public String getMusTrack() {
		ItemRecord itemrecord = (ItemRecord)(new ItemStack(MusDiscID, 1, 0).getItem());
		return itemrecord.recordName;
	}
	
	public int teamCloth(int teamNum) {
		if(teamNum == 0) {
			return 8;
		} else if(teamNum == 1) {
			return 14;
		} else if(teamNum == 2) {
			return 4;
		} else if(teamNum == 3) {
			return 13;
		} else if(teamNum == 4) {
			return 11;
		} else if(teamNum == 5) {
			return 1;
		} else if(teamNum == 6) {
			return 10;
		} else if(teamNum == 7) {
			return 6;
		} else if(teamNum == 8) {
			return 12;
		} else if(teamNum == 9) {
			return 0;
		} else {
			return 15;
		}
	}
	
	public int teamDye(int teamNum) {
		if(teamNum == 0) {
			return 8;
		} else if(teamNum == 1) {
			return 1;
		} else if(teamNum == 2) {
			return 11;
		} else if(teamNum == 3) {
			return 2;
		} else if(teamNum == 4) {
			return 4;
		} else if(teamNum == 5) {
			return 14;
		} else if(teamNum == 6) {
			return 5;
		} else if(teamNum == 7) {
			return 9;
		} else if(teamNum == 8) {
			return 3;
		} else if(teamNum == 9) {
			return 15;
		} else {
			return 0;
		}
	}
	
	public boolean goingToBlock() {
		return blockX != 0 || blockY != 0 || blockX != 0;
	}
	
	public void onLivingUpdate() {
		if(hasMusicDisc > 20*60*8 && MusDiscID != 0) {
			MusicCoord = new int[] { (int)posX, (int)posY, (int)posZ };
			worldObj.playRecord(getMusTrack(), MusicCoord[0], MusicCoord[1], MusicCoord[2]);
		}
		
		if(hasMusicDisc > 0) {
			hasMusicDisc--;
			if(ticksExisted % 10 == 0) ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityNoteFX(worldObj,  (double)posX, (double)posY + 0.5D, (double)posZ, rand.nextFloat(), rand.nextFloat(), rand.nextFloat()));
		}
		
		if(hasMusicDisc <= 0 && MusDiscID != 0) {
			worldObj.playRecord(null, MusicCoord[0], MusicCoord[1], MusicCoord[2]);
			dropItem(MusDiscID, 1);
			MusDiscID = 0;
			
		}
		
		if(strikeTime > 0) {
			strikeTime --;
		}
		
		if(victory > 0) {
			victory --;
		}
		
		if(corrupt) {
			essence --;
			if(essence <= 0) {
				hurtTime = 0;
				attackEntityFrom(DamageSource.causeMobDamage(this), health + 20);
			}
			
			if(rand.nextInt(2) == 0 && ModLoader.getMinecraftInstance().gameSettings.fancyGraphics)
			{
				addSquirrelButts();
			}
		}
		
		fleeingTick = 0;
		
		if(sugarTime > 0 || superSoldier) {
			moveSpeed = 0.5F + (!goingToBlock() && entityToAttack == null && targetFollow == null ? 0.0F : 0.25F);
			if(sugarTime > 0) {sugarTime --;}
		} else {
			moveSpeed = 0.3F + (!goingToBlock() && entityToAttack == null && targetFollow == null ? 0.0F : 0.15F);
		}
		
		if(handleWaterMovement()) {
			isJumping = true;
		}
		
		if(foodLeft > 0 && health <= 15 && health > 0) {
			for(int j = 0; j < 8; j++)
            {
                Vec3D vec3d = Vec3D.createVector(((double)rand.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                vec3d.rotateAroundX((-rotationPitch * 3.141593F) / 180F);
                vec3d.rotateAroundY((-rotationYaw * 3.141593F) / 180F);
                Vec3D vec3d1 = Vec3D.createVector(((double)rand.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-rand.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                vec3d1.rotateAroundX((-rotationPitch * 3.141593F) / 180F);
                vec3d1.rotateAroundY((-rotationYaw * 3.141593F) / 180F);
                vec3d1 = vec3d1.addVector(posX, posY + (double)getEyeHeight(), posZ);
                worldObj.spawnParticle((new StringBuilder()).append("iconcrack_").append(Item.porkRaw.shiftedIndex).toString(), vec3d1.xCoord, vec3d1.yCoord, vec3d1.zCoord, vec3d.xCoord, vec3d.yCoord + 0.050000000000000003D, vec3d.zCoord);
            }
			health += 15;
			foodLeft --;
		}
		
		if(onGround) {
			climbTime = 10;
		}
		
		if(smokeTime > 0) {
			smokeTime --;
		}
		
		if(throwTime > 0) {
			throwTime --;
		}
		
		if(hasFeather && !featherDeployed && gooTime <= 0 && !onGround && fallDistance >= 3F && logs <= 0 && !heavyCore && ridingEntity == null) {
			featherDeployed = true;
		}
		
		if(featherDeployed) {
			throwTime = 5;
			strikeTime = 5;
			fallDistance = 0F;
			motionX *= 0.8D;
			motionZ *= 0.8D;
			if(motionY < -0.08D) {
				motionY = -0.08D;
			}
			
			if(motionY >= 0D || onGround || handleWaterMovement()) {
				featherDeployed = false;
			}
		}
		
		if(gooTime > 0) {
			motionX = 0D;
			motionY = 0D;
			motionZ = 0D;
			moveForward = 0F;
			moveStrafing = 0F;
			isJumping = false;
			moveSpeed = 0F;
			
			gooTime --;
			
			int i = MathHelper.floor_double(posX);
			int j = MathHelper.floor_double(boundingBox.minY - 1D);
			int k = MathHelper.floor_double(posZ);
			int p = worldObj.getBlockId(i, j, k);
			if(j > 0 && j < 128 && (p == 0 || Block.blocksList[p].getCollisionBoundingBoxFromPool(worldObj, i, j, k) == null)) {
				gooTime = 0;
			}
		}
		
		if(throwTime > 6) {
			moveSpeed = -moveSpeed;
		}
		
		super.onLivingUpdate();
		
		if(!hasPath()) {
			blockX = 0;
			blockY = 0;
			blockZ = 0;
		}
		
		if(isSwinging) {
            prevSwingProgress += 0.15F;
            swingProgress += 0.15F;

            if(prevSwingProgress > 1.0F || swingProgress > 1.0F) {
                isSwinging = false;
                prevSwingProgress = 0.0F;
                swingProgress = 0.0F;
            }
        }
		
		if(isSwingingLeft) {
            swingLeft += 0.15F;

            if(swingLeft > 1.0F) {
                isSwingingLeft = false;
                swingLeft = 0.0F;
            }
        }
		
		if(superSoldier) {
			processCape();
		}
	}
	
	public void updateEntityActionState() {
		super.updateEntityActionState();
		
		entCount ++;
		
		if(entityToAttack != null && entityToAttack.isDead) {
			entityToAttack = null;
			setPathToEntity((PathEntity)null);
		} else if(entityToAttack != null && rand.nextInt(25) == 0 && (getDistanceToEntity(entityToAttack) > goggleView() || !canEntityBeSeen(entityToAttack))) {
			entityToAttack = null;
			setPathToEntity((PathEntity)null);
		}
		
		EntityPlayerSP ep = ModLoader.getMinecraftInstance().thePlayer;
		if(entityToAttack == null && (targetFollow == null || targetFollow == ep) && ep != null && canEntityBeSeen(ep)) {
			ItemStack held = ep.getCurrentEquippedItem();
			if(held != null) {
				if(held.itemID == Item.dyePowder.shiftedIndex && held.getItemDamage() == teamDye(clayTeam)) {
					targetFollow = ep;
				} else {
					targetFollow = null;
				}
			}
		}
			
		if(targetFollow != null && targetFollow.isDead) {
			targetFollow = null;
			setPathToEntity((PathEntity)null);
		} else if(targetFollow != null && rand.nextInt(25) == 0 && (getDistanceToEntity(targetFollow) > goggleView() || !canEntityBeSeen(targetFollow))) {
			targetFollow = null;
			setPathToEntity((PathEntity)null);
		}
		
		if(blazeStock > 0 && ticksExisted % (20 + (rand.nextInt(2)==0?-1:1)*rand.nextInt(4)) == 0) {
			worldObj.spawnParticle("flame", posX, posY+0.1D, posZ, 0.0D, 0.01D, 0.0D);
		}
		
		if(smokeTime <= 0 && entCount > 2 + rand.nextInt(2) && health > 0) {
			entCount = 0;
			List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(goggleView(), 5D, goggleView()));
			for(int j = 0; j < list.size(); j++) {
				Entity entity = (Entity)list.get(j);
				if(victory <= 0 && entity instanceof CSM_EntityClayMan && rand.nextInt(3) == 0 && canEntityBeSeen(entity) && logs <= 0) {
					CSM_EntityClayMan clayman = (CSM_EntityClayMan)entity;
					if(clayman.health > 0 && (!corrupt && clayTeam > 0 && clayTeam != 9 && (clayman.clayTeam != this.clayTeam || clayTeam == 10)) || (corrupt && !clayman.corrupt)) {
						if(clayman.king) {
							if(entityToAttack != null && entityToAttack instanceof CSM_EntityClayMan) {
								CSM_EntityClayMan clayman2 = (CSM_EntityClayMan)entityToAttack;
								if(!clayman2.king) {
									entityToAttack = clayman;
									break;
								}
							} else {
								entityToAttack = clayman;
								break;
							}
						} else if(entityToAttack == null) {
							entityToAttack = clayman;
							break;
						}
					} else if(clayman.health > 0 && targetFollow == null && entityToAttack == null && clayman.king && clayman.clayTeam == this.clayTeam && getDistanceToEntity(clayman) > 3.0D) {
						targetFollow = clayman;
						break;
					}
				} else if(victory <= 0 && !corrupt && clayTeam != 9 && entityToAttack == null && entity instanceof EntityMob && canEntityBeSeen(entity)) {
					EntityMob mob = (EntityMob)entity;
					if(mob.entityToAttack != null) {
						entityToAttack = mob;
						break;
					}
				} else if(victory <= 0 && corrupt && entityToAttack == null && entity instanceof EntityPlayer && canEntityBeSeen(entity)) {
					entityToAttack = entity;
					break;
				} else if(corrupt) {
					continue;
				} else if(entityToAttack == null && targetFollow == null && !heavyCore && logs <= 0 && ridingEntity == null && entity instanceof CSM_EntityDirtHorse && entity.riddenByEntity == null && canEntityBeSeen(entity)) {
					targetFollow = entity;
					break;
				} else if(entityToAttack == null && targetFollow == null && entity instanceof EntityFishHook && canEntityBeSeen(entity)) {
					targetFollow = entity;
					break;
				} else if(entityToAttack == null && (targetFollow == null || targetFollow instanceof CSM_EntityClayMan) && entity instanceof EntityItem && canEntityBeSeen(entity)) {
					EntityItem item = (EntityItem)entity;
					if(item.item != null) {
						ItemStack stack = item.item;
						if(stack.stackSize > 0) {
							if(clayTeam != 9 && weaponPoints <= 0 && stack.itemID == Item.stick.shiftedIndex) {
								targetFollow = item;
								break;
							} else if (clayTeam != 9 && hasMusicDisc <= 0 && stack.getItem() instanceof ItemRecord) {/*ADDED*/
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && !hasBlazeRod() && weaponPoints <= 0 && stack.itemID == Item.blazeRod.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(armorPoints <= 0 && stack.itemID == Item.leather.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(shieldPts <= 0 && stack.itemID == Item.bowlEmpty.shiftedIndex && rocks <= 0) {
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && rocks <= 0 && stack.itemID == Block.gravel.blockID && shieldPts <= 0) {
								targetFollow = item;
								break;
							} else if(!glowing && stack.itemID == Item.lightStoneDust.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(!king && clayTeam != 10 && stack.itemID == Item.goldNugget.shiftedIndex) {
								boolean jack = false;
								List list2 = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(24D, 16D, 24D));
								for(int k = 0; k < list2.size(); k++) {
									Entity entity2 = (Entity)list2.get(k);
									if(entity2 instanceof CSM_EntityClayMan) {
										CSM_EntityClayMan clayman = (CSM_EntityClayMan)entity2;
										if(clayman.clayTeam == this.clayTeam && clayman.king) {
											jack = true;
											break;
										}
									}
								}
								
								if(!jack) {
									targetFollow = item;
									break;
								}
							} else if(!superSoldier && stack.itemID == Item.diamond.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(!corrupt && stack.itemID == Item.enderPearl.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(!gunpowdered && stack.itemID == Item.gunpowder.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(!superSoldier && sugarTime <= 0 && stack.itemID == Item.sugar.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(foodLeft <= 0 && stack.getItem() != null && stack.getItem() instanceof ItemFood) {
								targetFollow = item;
								break;
							} else if(clayTeam != 10 && resPoints <= 0 && stack.itemID == Item.clay.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 10 && ghastTearPts <= 0 && stack.itemID == Item.ghastTear.shiftedIndex) {/*ADDED*/
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && gooStock <= 0 && stack.itemID == Item.slimeBall.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && smokeStock <= 0 && stack.itemID == Item.redstone.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && blazeStock <= 0 && stack.itemID == Item.blazePowder.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && weaponPoints > 0 && !stickSharp && stack.itemID == Item.flint.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 9 && weaponPoints <= 0 && stack.itemID == Item.arrow.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(armorPoints > 0 && !armorPadded && stack.itemID == Block.cloth.blockID) {
								targetFollow = item;
								break;
							} else if(!goggles && stack.itemID == Block.glass.blockID) {
								targetFollow = item;
								break;
							} else if(!heavyCore && ridingEntity == null && !hasFeather && stack.itemID == Item.ingotIron.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(!hasFeather && !heavyCore && stack.itemID == Item.feather.shiftedIndex) {
								targetFollow = item;
								break;
							} else if(clayTeam != 10 && resPoints > 0 && stack.getItem() != null && stack.getItem() instanceof CSM_ItemClayMan) {
								if(stack.getItemDamage() == this.clayTeam) {
									targetFollow = item;
									break;
								}
							} else if(clayTeam != 10 && ghastTearPts > 0 && stack.getItem() != null && stack.itemID == mod_ClayMan.brickDoll.shiftedIndex) {/*ADDED*/
								targetFollow = item;
								break;
							} else if(resPoints > 0 && ridingEntity == null && stack.getItem() != null && stack.getItem() instanceof CSM_ItemDirtHorse) {
								targetFollow = item;
								break;
							} else if(stack.itemID == Item.dyePowder.shiftedIndex && stack.getItemDamage() == teamDye(clayTeam)) {
								targetFollow = item;
								break;
							} else if(stack.itemID == Block.wood.blockID && ridingEntity == null) {
								int gottam = 0;
								if(logs < 20 && stack.stackSize >= 5) {
									gottam = 1;
								}
								
								if(gottam > 0) {
									targetFollow = item;
									break;
								}
							}
						}
					}
				} else if(entityToAttack == null && targetFollow == null && rand.nextInt(4) == 0 && entity instanceof EntityMinecart && canEntityBeSeen(entity)) {
					EntityMinecart cart = (EntityMinecart)entity;
					if(cart.minecartType == 1 && cartOperations(cart, false)) {
						targetFollow = cart;
						break;
					}
				}
			}
			
			if(entityToAttack != null) {
				if(hasBlazeRod() && strikeTime <= 0 && canEntityBeSeen(entityToAttack) && getDistanceToEntity(entityToAttack) < 0.6D + entityToAttack.width + (entityToAttack instanceof EntityPlayer ? 1.0F : 0F) + (rand.nextFloat() * 0.2D)) {
					entityToAttack.setFire(4);
					if(entityToAttack.attackEntityFrom(DamageSource.causeMobDamage(this), (3 + rand.nextInt(2)) + (superSoldier ? 2 : 0)))
						if(superSoldier) {
							ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityCrit2FX(worldObj, entityToAttack));
						}
					if(entityToAttack instanceof EntityLiving) {
						if(((EntityLiving)entityToAttack).health <= 0) {
							if(!corrupt) {
								victory = 50;
							}
							entityToAttack = null;
							setPathToEntity((PathEntity)null);
						}
					}
				} else if(strikeTime <= 0 && canEntityBeSeen(entityToAttack) && getDistanceToEntity(entityToAttack) < (weaponPoints > 0 ? 0.6D : 0.3D) + entityToAttack.width + (entityToAttack instanceof EntityPlayer ? 1.0F : 0F) + (rand.nextFloat() * 0.2D)) {
					if(hitTargetMakesDead(entityToAttack)) {
						entityToAttack = null;
						setPathToEntity((PathEntity)null);
					}
				} else if(rocks > 0 && throwTime <= 0 && canEntityBeSeen(entityToAttack)) {
					double frogman = getDistanceToEntity(entityToAttack);
					if(frogman >= 1.75D && frogman <= 7D) {
						rocks --;
						throwTime = 20;
						throwRockAtEnemy(entityToAttack);
					}
				}
			} else if(!corrupt && targetFollow != null) {
				if(!hasPath() || rand.nextInt(10) == 0) {
					setPathToEntity(worldObj.getPathToEntity(targetFollow, this, 16F));
				}
				if(targetFollow instanceof EntityItem) {
					EntityItem item = (EntityItem)targetFollow;
					if(item.item != null && canEntityBeSeen(item) && getDistanceToEntity(item) < 0.75D) {
						ItemStack stack = item.item;
						if(stack.stackSize > 0) {
							if(stack.itemID == Item.stick.shiftedIndex && !hasBlazeRod()) {
								weaponPoints = 15 * (superSoldier ? 3 : 1);
								stickSharp = false;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.arrow.shiftedIndex) {
								weaponPoints = 15 * (superSoldier ? 3 : 1);
								stickSharp = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.getItem() instanceof ItemRecord && hasMusicDisc <= 0) {
								hasMusicDisc = 20*60*8+1;
								MusDiscID = stack.itemID;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.blazeRod.shiftedIndex && !hasStick()) {
								hasBlazeRod = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.leather.shiftedIndex) {
								armorPoints = 15 * (superSoldier ? 3 : 1);
								armorPadded = false;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.bowlEmpty.shiftedIndex) {
								shieldPts = 10 * (superSoldier ? 3 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Block.gravel.blockID) {
								rocks = 15 * (superSoldier ? 3 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.lightStoneDust.shiftedIndex) {
								glowing = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.goldNugget.shiftedIndex) {
								boolean jack = false;
								List list2 = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(24D, 16D, 24D));
								for(int k = 0; k < list2.size(); k++) {
									Entity entity2 = (Entity)list2.get(k);
									if(entity2 instanceof CSM_EntityClayMan) {
										CSM_EntityClayMan clayman = (CSM_EntityClayMan)entity2;
										if(clayman.clayTeam == this.clayTeam && clayman.king) {
											jack = true;
											break;
										}
									}
								}
								
								if(clayTeam != 10 && !jack) {
									king = true;
									gotcha((EntityItem)targetFollow);
									item.setEntityDead();
								} else {
									targetFollow = null;
									setPathToEntity((PathEntity)null);
								}
							} else if(stack.itemID == Item.gunpowder.shiftedIndex) {
								gunpowdered = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.sugar.shiftedIndex) {
								sugarTime = 1200;
								gotcha((EntityItem)targetFollow);
							} else if(stack.getItem() != null && stack.getItem() instanceof ItemFood) {
								foodLeft = 4 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.clay.shiftedIndex) {
								resPoints = 4 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.ghastTear.shiftedIndex) {
								ghastTearPts = 1 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.redstone.shiftedIndex) {
								smokeStock = 2 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.blazePowder.shiftedIndex) {
								blazeStock = 1 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.slimeBall.shiftedIndex) {
								gooStock = 2 * (superSoldier ? 2 : 1);
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.ingotIron.shiftedIndex) {
								heavyCore = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.feather.shiftedIndex) {
								hasFeather = true;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.diamond.shiftedIndex) {
								superSoldier = true;
								health *= 20;
								weaponPoints *= 3;
								armorPoints *= 3;
								shieldPts *= 3;
								rocks *= 3;
								resPoints *= 2;
								foodLeft *= 2;
								smokeStock *= 2;
								gooStock *= 2;
								ghastTearPts *= 2;
								gotcha((EntityItem)targetFollow);
							} else if(stack.itemID == Item.enderPearl.shiftedIndex) {
								corrupt = true;
								this.health = Math.max(this.health, 30);
								essence = 3600;
								worldObj.playSoundAtEntity(this, "mob.ghast.scream", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
								gotcha((EntityItem)targetFollow); 
							} else if(stack.itemID == Item.flint.shiftedIndex) {
								if(weaponPoints > 0) {
									stickSharp = true;
									for(int j = 0; j < 4; j++) {
										double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
										double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.planks, 0, 0)));
									}
									worldObj.playSoundAtEntity(this, "random.wood click", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
								}
								targetFollow = null;
							} else if(stack.itemID == Block.cloth.blockID) {
								if(armorPoints > 0) {
									armorPadded = true;
									for(int j = 0; j < 4; j++) {
										double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
										double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, 0)));
									}
									worldObj.playSoundAtEntity(this, "step.cloth", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
								}
								targetFollow = null;
							} else if(stack.itemID == Block.glass.blockID) {
								if(!goggles) {
									goggles = true;
									for(int j = 0; j < 4; j++) {
										double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
										double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.glass, 0, 0)));
									}
									worldObj.playSoundAtEntity(this, "random.glass", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
								}
								targetFollow = null;
							} else if(stack.getItem() != null && stack.getItem() instanceof CSM_ItemClayMan) {
								swingArm();
								worldObj.playSoundAtEntity(item, "step.gravel", 0.8F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) * 0.9F);
								for(int q = 0; q < 18; q++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, teamCloth(clayTeam)));
								}
								CSM_EntityClayMan ec = new CSM_EntityClayMan(worldObj, item.posX, item.posY, item.posZ, clayTeam);
								worldObj.spawnEntityInWorld(ec);
								gotcha((EntityItem)targetFollow);
								resPoints --;
							} else if(stack.getItem() != null && stack.itemID == mod_ClayMan.brickDoll.shiftedIndex) { /*ADDED*/
								swingArm();
								worldObj.playSoundAtEntity(item, "step.gravel", 0.8F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) * 0.9F);
								for(int q = 0; q < 18; q++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, teamCloth(clayTeam)));
								}
								CSM_EntityClayMan ec = new CSM_EntityClayMan(worldObj, item.posX, item.posY, item.posZ, clayTeam);
								worldObj.spawnEntityInWorld(ec);
								gotcha((EntityItem)targetFollow);
								ghastTearPts --;
							} else if(stack.getItem() != null && stack.getItem() instanceof CSM_ItemDirtHorse) {
								swingArm();
								worldObj.playSoundAtEntity(item, "step.gravel", 0.8F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) * 0.9F);
								for(int q = 0; q < 18; q++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.blockClay, 0, 0));
								}
								CSM_EntityDirtHorse ed = new CSM_EntityDirtHorse(worldObj, item.posX, item.posY, item.posZ, stack.getItemDamage());
								if(stack.getItem() == mod_ClayMan.pegasusDoll) {
									ed = new CSM_EntitySnowPegasus(worldObj, item.posX, item.posY, item.posZ, stack.getItemDamage());
								}
								worldObj.spawnEntityInWorld(ed);
								gotcha((EntityItem)targetFollow);
								resPoints --;
							} else if(stack.itemID == Block.wood.blockID && ridingEntity == null) {
								int gottam = 0;
								if(logs < 20 && stack.stackSize >= 5) {
									gottam = 1;
								}
								
								if(gottam > 0) {
									worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
									if(gottam == 1) {
										logs += 5;
										if(item.item != null) {
											item.item.stackSize -= 5;
										}
									}
									
									if(item.item == null || item.item.stackSize <= 0) {
										item.setEntityDead();
									}
								}
								
								setPathToEntity((PathEntity)null);
								targetFollow = null;
							} else if(stack.itemID == Item.dyePowder.shiftedIndex) {
								targetFollow = null;
							}
						}
					}
				} else if(targetFollow instanceof CSM_EntityClayMan && getDistanceToEntity(targetFollow) < 1.75D) {
					targetFollow = null;
				} else if(targetFollow instanceof EntityFishHook && getDistanceToEntity(targetFollow) < 1.0D) {
					targetFollow = null;
				} else if(targetFollow instanceof CSM_EntityDirtHorse && getDistanceToEntity(targetFollow) < 0.75D && gooTime <= 0) {
					if(ridingEntity == null && targetFollow.riddenByEntity == null && !heavyCore && logs <= 0) {
						mountEntity(targetFollow);
						worldObj.playSoundAtEntity(this, "step.gravel", 0.6F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
					}
					targetFollow = null;
				} else if(targetFollow instanceof EntityMinecart && getDistanceToEntity(targetFollow) < 1.25D) {
					cartOperations((EntityMinecart)targetFollow, true);
					targetFollow = null;
				}
			} else if(!corrupt) {
				updateBlockFinder();
				if(logs > 0 && rand.nextInt(16) == 0) {
					updateBuildings();
				}
			}
		}
	}
	
	public void updateBlockFinder() {
		int x = MathHelper.floor_double(posX);
        int y = MathHelper.floor_double(boundingBox.minY);
        int z = MathHelper.floor_double(posZ);
		
		if(blockX != 0 && blockY != 0 && blockZ != 0 && !hasPath()) {
			PathEntity emily = worldObj.getEntityPathToXYZ(this, blockX, blockY, blockZ, 16F);
			if(emily != null && rand.nextInt(5) != 0) {
				setPathToEntity(emily);
			} else {
				blockX = 0;
				blockY = 0;
				blockZ = 0;
			}
		}
		
		int i = x;
		int j = y;
		int k = z;
		
		for(int q = 0; q < 32; q++) {
			if(j < 4 || j > 124 || !isAirySpace(i, j, k) || isAirySpace(i, j - 1, k)) {
				continue;
			}
		
			int a = i;
			int b = j - 1;
			int c = k;
			if(checkSides(a, b, c, i, j, k, blocDist(a, b, c, x, y, z), q == 0)) {
				
				break;
			}
			
			b += 1;
			a -= 1;
			
			if(checkSides(a, b, c, i, j, k, blocDist(a, b, c, x, y, z), q == 0)) {
				
				break;
			}
			
			a += 2;
			
			if(checkSides(a, b, c, i, j, k, blocDist(a, b, c, x, y, z),q == 0)) {
				
				break;
			}
			
			a -= 1;
			c -= 1;
			
			if(checkSides(a, b, c, i, j, k, blocDist(a, b, c, x, y, z),q == 0)) {
				
				break;
			}
			
			c += 2;
			
			if(checkSides(a, b, c, i, j, k, blocDist(a, b, c, x, y, z),q == 0)) {
				
				break;
			}
			
			i = x + rand.nextInt(8) - rand.nextInt(8);
			j = y + rand.nextInt(4) - rand.nextInt(4);
			k = z + rand.nextInt(8) - rand.nextInt(8);
		}
	}
	
	public void processCape() {
		field_20066_r = field_20063_u;
        field_20065_s = field_20062_v;
        field_20064_t = field_20061_w;
        double d = posX - field_20063_u;
        double d1 = posY - field_20062_v;
        double d2 = posZ - field_20061_w;
        double d3 = 10D;
        if(d > d3)
        {
            field_20066_r = field_20063_u = posX;
        }
        if(d2 > d3)
        {
            field_20064_t = field_20061_w = posZ;
        }
        if(d1 > d3)
        {
            field_20065_s = field_20062_v = posY;
        }
        if(d < -d3)
        {
            field_20066_r = field_20063_u = posX;
        }
        if(d2 < -d3)
        {
            field_20064_t = field_20061_w = posZ;
        }
        if(d1 < -d3)
        {
            field_20065_s = field_20062_v = posY;
        }
        field_20063_u += d * 0.25D;
        field_20061_w += d2 * 0.25D;
        field_20062_v += d1 * 0.25D;
	}
	
	private double goggleView() {
		if(goggles) {
			return 13D;
		} else {
			return 8D;
		}
	}
	
	public double blocDist(int a, int b, int c, int x, int y, int z) {
		double i = (double)(a - x);
		double j = (double)(b - y);
		double k = (double)(c - z);
		return Math.sqrt((i * i) + (j * j) + (k * k));
	}
	
	public boolean isAirySpace(int x, int y, int z) { 
		int p = worldObj.getBlockId(x, y, z);
		return p == 0 || Block.blocksList[p].getCollisionBoundingBoxFromPool(worldObj, x, y, z) == null;
	}
	
	public boolean checkSides(int a, int b, int c, int i, int j, int k, double dist, boolean first) {
		if(b > 4 && b < 124) {
			if(worldObj.getBlockId(a, b, c) == Block.chest.blockID) {
				if(first && blockX == i && blockY == j && blockZ == k) {
					setPathToEntity((PathEntity)null);
					blockX = 0;
					blockY = 0;
					blockZ = 0;
					chestOperations(a, b, c, true);
					return true;
				} else if(blockX == 0 && blockY == 0 && blockZ == 0) {
					if(chestOperations(a, b, c, false)) {
						PathEntity emily = worldObj.getEntityPathToXYZ(this, i, j, k, 16F);
						if(emily != null) {
							setPathToEntity(emily);
							blockX = i;
							blockY = j;
							blockZ = k;
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	public boolean chestOperations(int x, int y, int z, boolean arrived) {
		TileEntity te = worldObj.getBlockTileEntity(x, y, z);
		if(te != null && te instanceof TileEntityChest) {
			TileEntityChest chest = (TileEntityChest)te;
			for(int q = 0; q < chest.getSizeInventory(); q++) {
				if(chest.getStackInSlot(q) != null) {
					ItemStack stack = chest.getStackInSlot(q);
					if(stack.stackSize > 0) {
						if(clayTeam != 9 && weaponPoints <= 0 && stack.itemID == Item.stick.shiftedIndex && !hasBlazeRod()) {
							if(arrived) {
								weaponPoints = 15 * (superSoldier ? 3 : 1);
								stickSharp = false;
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && !hasBlazeRod() && weaponPoints <= 0 && stack.itemID == Item.blazeRod.shiftedIndex) {
							if(arrived) {
								hasBlazeRod = true;
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && stack.getItem() instanceof ItemRecord && hasMusicDisc <= 0) {
							if(arrived) {
								hasMusicDisc = 20*60*8+1;
								MusDiscID = stack.itemID;
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && !hasBlazeRod() && weaponPoints <= 0  && stack.itemID == Item.arrow.shiftedIndex) {
							if(arrived) {
								weaponPoints = 15 * (superSoldier ? 3 : 1);
								stickSharp = true;
								gotcha(chest, q);
							}
							return true;
						} else if(armorPoints <= 0 && stack.itemID == Item.leather.shiftedIndex) {
							if(arrived) {
								armorPoints = 15 * (superSoldier ? 3 : 1);
								armorPadded = false;
								gotcha(chest, q);
							}
							return true;
						} else if(shieldPts <= 0 && stack.itemID == Item.bowlEmpty.shiftedIndex && rocks <= 0) {
							if(arrived) {
								shieldPts = 10 * (superSoldier ? 3 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && rocks <= 0 && shieldPts <= 0 && stack.itemID == Block.gravel.blockID) {
							if(arrived) {
								rocks = 15 * (superSoldier ? 3 : 1);
								gotcha(chest, q);
							}
							return true;
							
						} else if(!glowing && stack.itemID == Item.lightStoneDust.shiftedIndex) {
							if(arrived) {
								glowing = true;
								gotcha(chest, q);
							}
							return true;
							
						} else if(clayTeam != 10 && !king && stack.itemID == Item.goldNugget.shiftedIndex) {
							boolean jack = false;
							List list2 = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(24D, 16D, 24D));
							for(int k = 0; k < list2.size(); k++) {
								Entity entity2 = (Entity)list2.get(k);
								if(entity2 instanceof CSM_EntityClayMan) {
									CSM_EntityClayMan clayman = (CSM_EntityClayMan)entity2;
									if(clayman.clayTeam == this.clayTeam && clayman.king) {
										jack = true;
										break;
									}
								}
							}
							
							if(!jack) {
								if(arrived) {
									king = true;
									gotcha(chest, q);
								}
								return true;
							}
						} else if(!gunpowdered && stack.itemID == Item.gunpowder.shiftedIndex) {
							if(arrived) {
								gunpowdered = true;
								gotcha(chest, q);
							}
							return true;
						} else if(!superSoldier && sugarTime <= 0 && stack.itemID == Item.sugar.shiftedIndex) {
							if(arrived) {
								sugarTime = 1200;
								gotcha(chest, q);
							}
							return true;
						} else if(foodLeft <= 0 && stack.getItem() != null && stack.getItem() instanceof ItemFood) {
							if(arrived) {
								foodLeft = 4 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 10 && resPoints <= 0 && stack.itemID == Item.clay.shiftedIndex) {
							if(arrived) {
								resPoints = 4 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 10 && ghastTearPts <= 0 && stack.itemID == Item.ghastTear.shiftedIndex) {
							if(arrived) {
								ghastTearPts = 1 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && gooStock <= 0 && stack.itemID == Item.slimeBall.shiftedIndex) {
							if(arrived) {
								gooStock = 2 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && smokeStock <= 0 && stack.itemID == Item.redstone.shiftedIndex) {
							if(arrived) {
								smokeStock = 2 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 9 && blazeStock <= 0 && stack.itemID == Item.blazePowder.shiftedIndex) {
							if(arrived) {
								blazeStock = 1 * (superSoldier ? 2 : 1);
								gotcha(chest, q);
							}
							return true;
						} else if(stack.itemID == Block.wood.blockID && ridingEntity == null) {
							int gottam = 0;
							if(logs < 20 && stack.stackSize >= 5) {
								gottam = 1;
							}
							
							if(arrived && gottam > 0) {
								worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
								if(gottam == 1) {
									logs += 5;
									chest.decrStackSize(q, 5);
								}
							}
							return gottam > 0 || arrived;
						} else if(clayTeam != 9 && weaponPoints > 0 && !stickSharp && stack.itemID == Item.flint.shiftedIndex) {
							if(arrived) {
								stickSharp = true;
								for(int j = 0; j < 4; j++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.planks, 0, 0)));
								}
								worldObj.playSoundAtEntity(this, "random.wood click", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
							}
							return true;
						} else if(armorPoints > 0 && !armorPadded && stack.itemID == Block.cloth.blockID) {
							if(arrived) {
								armorPadded = true;
								for(int j = 0; j < 4; j++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, 0)));
								}
								worldObj.playSoundAtEntity(this, "step.cloth", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
							}
							return true;
						} else if(!goggles && stack.itemID == Block.glass.blockID) {
							if(arrived) {
								goggles = true;
								for(int j = 0; j < 4; j++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.glass, 0, 0)));
								}
								worldObj.playSoundAtEntity(this, "random.glass", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
							}
							return true;
						} else if(!heavyCore && !hasFeather && ridingEntity == null && stack.itemID == Item.ingotIron.shiftedIndex) {
							if(arrived) {
								heavyCore = true;
								gotcha(chest, q);
							}
							return true;
						} else if(!heavyCore && !hasFeather && stack.itemID == Item.feather.shiftedIndex) {
							if(arrived) {
								hasFeather = true;
								gotcha(chest, q);
							}
							return true;
						} else if(!superSoldier && stack.itemID == Item.diamond.shiftedIndex) {
							if(arrived) {
								superSoldier = true;
								health *= 20;
								weaponPoints *= 3;
								armorPoints *= 3;
								rocks *= 3;
								shieldPts *= 3;
								resPoints *= 2;
								ghastTearPts *= 2;
								foodLeft *= 2;
								smokeStock *= 2;
								gooStock *= 2;
								gotcha(chest, q);
							}
							return true;
						} else if(!corrupt && stack.itemID == Item.enderPearl.shiftedIndex) {
							if(arrived) {
								corrupt = true;
								this.health = Math.max(this.health, 30);
								essence = 3600;
								worldObj.playSoundAtEntity(this, "mob.ghast.scream", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
								gotcha(chest, q);
							}
							return true;
						} else if(clayTeam != 10 && resPoints > 0 && stack.getItem() != null && stack.getItem() instanceof CSM_ItemClayMan) {
//							CSM_ItemClayMan ic = (CSM_ItemClayMan)stack.getItem();
							if(stack.getItemDamage() == this.clayTeam) {
								if(arrived) {
									swingArm();
									for(int u = 0; u < 18; u++) {
										double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
										ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, teamCloth(clayTeam)));
									}
									
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + (rand.nextFloat() * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									
									CSM_EntityClayMan ec = new CSM_EntityClayMan(worldObj, a, b, c, clayTeam);
									worldObj.spawnEntityInWorld(ec);
									gotcha(chest, q);
									resPoints --;
								}
								return true;
							}
						} else if(resPoints > 0 && ridingEntity == null && stack.getItem() != null && stack.getItem() instanceof CSM_ItemDirtHorse) {
							if(arrived) {
								swingArm();
								for(int u = 0; u < 18; u++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.blockClay, 0, 0));
								}
								
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = posY + (rand.nextFloat() * 0.125D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								
								CSM_EntityDirtHorse ed = new CSM_EntityDirtHorse(worldObj, a, b, c, stack.getItemDamage());
								if(stack.getItem() == mod_ClayMan.pegasusDoll) {
									ed = new CSM_EntitySnowPegasus(worldObj, a, b, c, stack.getItemDamage());
								}
								worldObj.spawnEntityInWorld(ed);
								gotcha(chest, q);
								resPoints --;
							}
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	public boolean cartOperations(EntityMinecart cart, boolean arrived) {
		for(int q = 0; q < cart.getSizeInventory(); q++) {
			ItemStack stack = cart.getStackInSlot(q);
			if(stack != null) {
				if(stack.stackSize > 0) {
					if(clayTeam != 9 && weaponPoints <= 0 && stack.itemID == Item.stick.shiftedIndex && !hasBlazeRod()) {
						if(arrived) {
							weaponPoints = 15 * (superSoldier ? 3 : 1);
							stickSharp = false;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && weaponPoints <= 0 && stack.itemID == Item.arrow.shiftedIndex && !hasBlazeRod()) {
						if(arrived) {
							weaponPoints = 15 * (superSoldier ? 3 : 1);
							stickSharp = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && !hasBlazeRod() && weaponPoints <= 0 && stack.itemID == Item.blazeRod.shiftedIndex) {
						if(arrived) {
							hasBlazeRod = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && stack.getItem() instanceof ItemRecord && hasMusicDisc <= 0) {
						if(arrived) {
							hasMusicDisc = 20*60*8+1;
							MusDiscID = stack.itemID;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(armorPoints <= 0 && stack.itemID == Item.leather.shiftedIndex) {
						if(arrived) {
							armorPoints = 15 * (superSoldier ? 3 : 1);
							armorPadded = false;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(shieldPts <= 0 && rocks <= 0 && stack.itemID == Item.bowlEmpty.shiftedIndex) {
						if(arrived) {
							shieldPts = 10 * (superSoldier ? 3 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && rocks <= 0 && shieldPts <= 0 && stack.itemID == Block.gravel.blockID) {
						if(arrived) {
							rocks = 15 * (superSoldier ? 3 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(!glowing && stack.itemID == Item.lightStoneDust.shiftedIndex) {
						if(arrived) {
							glowing = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
						
					} else if(clayTeam != 10 && !king && stack.itemID == Item.goldNugget.shiftedIndex) {
						boolean jack = false;
						List list2 = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(24D, 16D, 24D));
						for(int k = 0; k < list2.size(); k++) {
							Entity entity2 = (Entity)list2.get(k);
							if(entity2 instanceof CSM_EntityClayMan) {
								CSM_EntityClayMan clayman = (CSM_EntityClayMan)entity2;
								if(clayman.clayTeam == this.clayTeam && clayman.king) {
									jack = true;
									break;
								}
							}
						}
						
						if(!jack) {
							if(arrived) {
								king = true;
								stack = cart.decrStackSize(q, 1);
							}
							return true;
						}
					} else if(!gunpowdered && stack.itemID == Item.gunpowder.shiftedIndex) {
						if(arrived) {
							gunpowdered = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(!superSoldier && sugarTime <= 0 && stack.itemID == Item.sugar.shiftedIndex) {
						if(arrived) {
							sugarTime = 1200;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(foodLeft <= 0 && stack.getItem() != null && stack.getItem() instanceof ItemFood) {
						if(arrived) {
							foodLeft = 4 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 10 && resPoints <= 0 && stack.itemID == Item.clay.shiftedIndex) {
						if(arrived) {
							resPoints = 4 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 10 && ghastTearPts <= 0 && stack.itemID == Item.ghastTear.shiftedIndex) {
						if(arrived) {
							ghastTearPts = 1 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && gooStock <= 0 && stack.itemID == Item.slimeBall.shiftedIndex) {
						if(arrived) {
							gooStock = 2 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && smokeStock <= 0 && stack.itemID == Item.redstone.shiftedIndex) {
						if(arrived) {
							smokeStock = 2 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 9 && blazeStock <= 0 && stack.itemID == Item.blazePowder.shiftedIndex) {
						if(arrived) {
							blazeStock = 1 * (superSoldier ? 2 : 1);
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(stack.itemID == Block.wood.blockID && ridingEntity == null) {
						int gottam = 0;
						if(logs < 20 && stack.stackSize >= 5) {
							gottam = 1;
						}
						
						if(arrived && gottam > 0) {
							worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
							if(gottam == 1) {
								logs += 5;
								stack = cart.decrStackSize(q, 5);
							}
						}
						return gottam > 0 || arrived;
					} else if(clayTeam != 9 && weaponPoints > 0 && !stickSharp && stack.itemID == Item.flint.shiftedIndex) {
						if(arrived) {
							stickSharp = true;
							for(int j = 0; j < 4; j++) {
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.planks, 0, 0)));
							}
							worldObj.playSoundAtEntity(this, "random.wood click", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
						}
						return true;
					} else if(armorPoints > 0 && !armorPadded && stack.itemID == Block.cloth.blockID) {
						if(arrived) {
							armorPadded = true;
							for(int j = 0; j < 4; j++) {
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, 0)));
							}
							worldObj.playSoundAtEntity(this, "step.cloth", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
						}
						return true;
					} else if(!goggles && stack.itemID == Block.glass.blockID) {
						if(arrived) {
							goggles = true;
							for(int j = 0; j < 4; j++) {
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.25D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								ModLoader.getMinecraftInstance().effectRenderer.addEffect((new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.glass, 0, 0)));
							}
							worldObj.playSoundAtEntity(this, "random.glass", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
						}
						return true;
					} else if(!heavyCore && !hasFeather && ridingEntity == null && stack.itemID == Item.ingotIron.shiftedIndex) {
						if(arrived) {
							heavyCore = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(!superSoldier && stack.itemID == Item.diamond.shiftedIndex) {
						if(arrived) {
							superSoldier = true;
							health *= 20;
							weaponPoints *= 3;
							armorPoints *= 3;
							shieldPts *= 3;
							rocks *= 3;
							resPoints *= 2;
							ghastTearPts *= 2;
							foodLeft *= 2;
							smokeStock *= 2;
							gooStock *= 2;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(!corrupt && stack.itemID == Item.enderPearl.shiftedIndex) {
						if(arrived) {
							corrupt = true;
							this.health = Math.max(this.health, 30);
							essence = 3600;
							worldObj.playSoundAtEntity(this, "mob.ghast.scream", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(!heavyCore && !hasFeather && stack.itemID == Item.feather.shiftedIndex) {
						if(arrived) {
							hasFeather = true;
							stack = cart.decrStackSize(q, 1);
						}
						return true;
					} else if(clayTeam != 10 && resPoints > 0 && stack.getItem() != null && stack.getItem() instanceof CSM_ItemClayMan) {
//						CSM_ItemClayMan ic = (CSM_ItemClayMan)stack.getItem();
						if(stack.getItemDamage() == this.clayTeam) {
							if(arrived) {
								swingArm();
								for(int u = 0; u < 18; u++) {
									double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
									ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, teamCloth(clayTeam)));
								}
								
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = posY + (rand.nextFloat() * 0.125D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								
								CSM_EntityClayMan ec = new CSM_EntityClayMan(worldObj, a, b, c, clayTeam);
								worldObj.spawnEntityInWorld(ec);
								
								stack = cart.decrStackSize(q, 1);
								resPoints --;
							}
							return true;
						}
					} else if(resPoints > 0 && ridingEntity == null && stack.getItem() != null && stack.getItem() instanceof CSM_ItemDirtHorse) {
						if(arrived) {
							swingArm();
							for(int u = 0; u < 18; u++) {
								double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
								ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.blockClay, 0, 0));
							}
							
							double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
							double b = posY + (rand.nextFloat() * 0.125D);
							double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
							
							CSM_EntityDirtHorse ed = new CSM_EntityDirtHorse(worldObj, a, b, c, stack.getItemDamage());
							if(stack.getItem() == mod_ClayMan.pegasusDoll) {
								ed = new CSM_EntitySnowPegasus(worldObj, a, b, c, stack.getItemDamage());
							}
							worldObj.spawnEntityInWorld(ed);
							stack = cart.decrStackSize(q, 1);
							resPoints --;
						}
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public void updateBuildings() {
		int x = MathHelper.floor_double(posX);
        int y = MathHelper.floor_double(boundingBox.minY);
        int z = MathHelper.floor_double(posZ);
		
		if(y < 4 || y > 120) {
			return;
		}
		
		int broad = 2;
		int high = 3;
		if(logs == 20) {
			broad = 3;
			high = 4;
		}
		
		boolean flag = false;
		for(int a = -broad; a < broad + 1 && !flag; a++) {
			for(int b = -1; b < high + 1 && !flag; b++) {
				for(int c = -broad; c < broad + 1 && !flag; c++) {
					if(b == -1) {
						if(isAirySpace(x + a, y + b, z + c)) {
							flag = true;
						}
					} else {
						if(!isAirySpace(x + a, y + b, z + c) || worldObj.getBlockMaterial(x + a, y + b, z + c) == Material.water) {
							flag = true;
						}
					}
				}
			}
		}
		
		if(!flag) {
			double gee = (double)broad;
			List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(gee, gee, gee));
			if(list.size() > 0) {
				flag = true;
			}
		}
		
		if(!flag) {
			if(logs == 20 && rand.nextInt(2) == 0) {
				buildHouseThree();
			} else if(logs >= 10 && rand.nextInt(3) > 0) {
				buildHouseTwo();
			} else if(logs >= 5) {
				buildHouseOne();
			}
		}
	}
	
	public boolean interact(EntityPlayer entityplayer) {
		if(mod_ClayMan.placeholder == null) {
			CSM_EntityClayCam eddie = new CSM_EntityClayCam(worldObj, this);
			mod_ClayMan.claycam = eddie;
			worldObj.spawnEntityInWorld(eddie);
			Minecraft game = ModLoader.getMinecraftInstance();
			game.renderViewEntity = eddie;
			mod_ClayMan.showTheHUD = game.gameSettings.hideGUI;
			mod_ClayMan.showTheGUY = game.gameSettings.thirdPersonView == 0;
			game.gameSettings.hideGUI = true;
			game.gameSettings.thirdPersonView = 0;
			mod_ClayMan.placeholder = entityplayer;
		}
		return false;
	}
	
	public void dropLogs() {
		dropItem(Block.wood.blockID, logs);
		logs = 0;
	}
	
	public void buildHouseOne() {
		int x = MathHelper.floor_double(posX + 0.5D);
        int y = MathHelper.floor_double(boundingBox.minY);
        int z = MathHelper.floor_double(posZ + 0.5D);
		
		int direction = rand.nextInt(4);
		
		for(int j = 0; j < 3; j++) {
			int b = j;
			for(int i = -1; i < 3; i++) {
				for(int k = -1; k < 2; k++) {
					int a = i;
					int c = k;
					
					if(direction % 2 == 0) {
						a = -a;
						c = -c;
					} 
					
					if(direction / 2 == 0) {
						int swap = a;
						a = c;
						c = swap;
					}
					
					if(j == 0) {
						if(i == -1 || i == 2 || k == -1) {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
						}
					} else if(j == 1) {
						if(i == -1) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2 + (direction % 2 == 0 ? 1 : -1)) % 4); 
						} else if(i == 2) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2) % 4); 
						} else if(k == -1) {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
						}
					} else {
						if(i == 0) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2 + (direction % 2 == 0 ? 1 : -1)) % 4);
						} else if(i == 1) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2) % 4); 
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
						}
					}
				}
			}
		}
		
		worldObj.playSoundAtEntity(this, "random.wood click", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		worldObj.playSoundAtEntity(this, "step.wood", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		logs -= 5;
	}
	
	public void buildHouseTwo() {
		int x = MathHelper.floor_double(posX);
        int y = MathHelper.floor_double(boundingBox.minY);
        int z = MathHelper.floor_double(posZ);
		
		int direction = rand.nextInt(4);
		
		for(int j = 0; j < 3; j++) {
			int b = j;
			for(int i = -2; i < 3; i++) {
				for(int k = -2; k < 3; k++) {
					int a = i;
					int c = k;
					
					if(direction % 2 == 0) {
						a = -a;
						c = -c;
					} 
					
					if(direction / 2 == 0) {
						int swap = a;
						a = c;
						c = swap;
					}
					
					if((i == -2 || i == 2) && (k == -2 || k == 2)) {
						continue;
					}
					
					if(j == 0 || j == 1) {
						if(i == -2 || i == 2 || k == -2 || (k == 2 && (i != 0 || j == 1))) {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
						}
					} else if(j == 2) {
						if(i == -2) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2 + (direction % 2 == 0 ? 1 : -1)) % 4);
						} else if(i == 2) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2) % 4); 
						} else if(k == -2) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + (direction % 2 == 0 ? 1 : -1)) % 4);
						} else if(k == 2) {
							worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
							worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction) % 4); 
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID);  
						}
					}
				}
			}
		}
		
		worldObj.playSoundAtEntity(this, "random.wood click", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		worldObj.playSoundAtEntity(this, "step.wood", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		logs -= 10;
	}
	
	public void buildHouseThree() {
		int x = MathHelper.floor_double(posX);
        int y = MathHelper.floor_double(boundingBox.minY);
        int z = MathHelper.floor_double(posZ);
		
		int direction = rand.nextInt(4);
		
		for(int j = 0; j < 4; j++) {
			int b = j;
			for(int i = -3; i < 4; i++) {
				for(int k = -2; k < 3; k++) {
					int a = i;
					int c = k;
					
					if(direction % 2 == 0) {
						a = -a;
						c = -c;
					} 
					
					if(direction / 2 == 0) {
						int swap = a;
						a = c;
						c = swap;
					}
					
					if((i == -3 || i == 3) && (k == -2 || k == 2)) {
						continue;
					}
					
					if(j < 3) {
						if(i == -3 || i == 3 || k == -2 || (k == 2 && (i != 0 || j > 0))) {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
						} else {
							if(i == -2 && j == 0 && k == 0) { 
								worldObj.setBlock(x + a, y + b, z + c, Block.chest.blockID); 
								worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2) % 4);
								TileEntityChest chest = (TileEntityChest)worldObj.getBlockTileEntity(x + a, y + b, z + c);
								chest.setInventorySlotContents(0, new ItemStack(Item.stick, 16, 0));
							} else if(i == 0 && j == 0 && k == -1) {
								worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
								worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2 + (direction % 2 == 0 ? 1 : -1)) % 4);
							} else if(i == 1 && j == 1 && k == -1) {
								worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
								worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + 2 + (direction % 2 == 0 ? 1 : -1)) % 4);
							} else if(i == 2 && j == 1 && k == -1) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
							} else if(i == 2 && j == 2 && k == 0) {
								worldObj.setBlock(x + a, y + b, z + c, Block.stairCompactPlanks.blockID); 
								worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, (direction + (direction % 2 == 0 ? 1 : -1)) % 4);
							} else if(i == 0 && j == 2 && k == -1) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
							} else if(i == 1 && j == 2 && k == -1) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
							} else if(i == 2 && j == 2 && k == -1) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
							} else if(j == 2) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID); 
							} else {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
							}
						}
					} else if(j == 3) {
						if(i == -3 || i == 3 || k == -2 || (k == 2 && (i != 0 || j > 0))) {
							if(i == -2 || i == 0 || i == 2 || k == 0) {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.planks.blockID);
							} else {
								worldObj.setBlockWithNotify(x + a, y + b, z + c, Block.stairSingle.blockID);
								worldObj.setBlockMetadataWithNotify(x + a, y + b, z + c, 2);
							}
						} else {
							worldObj.setBlockWithNotify(x + a, y + b, z + c, 0); 
						}
					}
				}
			}
		}
		
		worldObj.playSoundAtEntity(this, "random.wood click", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		worldObj.playSoundAtEntity(this, "step.wood", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		logs -= 20;
	}
	
	public void moveEntityWithHeading(float f, float f1)
    {
		super.moveEntityWithHeading(f, f1);
		double d2 = (posX - prevPosX) * 2.0F;
        double d3 = (posZ - prevPosZ) * 2.0F;
		float f5 = MathHelper.sqrt_double(d2 * d2 + d3 * d3) * 4F;
        if(f5 > 1.0F)
        {
            f5 = 1.0F;
        }
        field_704_R += (f5 - field_704_R) * 0.4F;
        field_703_S += field_704_R;
	}
	
	public void swingArm() {
        if(!isSwinging) {
            isSwinging = true;
            prevSwingProgress = 0.0F;
            swingProgress = 0.0F;
        }
    }
	
	public void swingLeftArm() {
        if(!isSwingingLeft) {
            isSwingingLeft = true;
            swingLeft = 0.01F;
        }
    }
	
	public boolean hitTargetMakesDead(Entity e) {
		strikeTime = 12 - (superSoldier ? 4 : 0);
		swingArm();
		int power = (weaponPoints > 0 ? 3 + rand.nextInt(2) + (stickSharp ? 1 : 0) : 2) + (superSoldier ? 2 : 0);
		if(weaponPoints > 0) {
			weaponPoints --;
		}
		boolean flag = e.attackEntityFrom(DamageSource.causeMobDamage(this), power);
		if(flag && e instanceof EntityLiving) {
			EntityLiving el = (EntityLiving)e;
			if(superSoldier) {
				ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityCrit2FX(worldObj, el));
			}
			if(el.health <= 0) {
				if(!corrupt) {
					victory = 50;
				}
				return true;
			}
		}
		return false;
	}
	
	public boolean canEntityBeSeen(Entity entity)
    {
        return worldObj.rayTraceBlocks(Vec3D.createVector(posX, posY + (double)getEyeHeight() + 0.2D, posZ), Vec3D.createVector(entity.posX, entity.posY + ((double)entity.getEyeHeight() / 4D), entity.posZ)) == null;
    }
	
	public void throwRockAtEnemy(Entity entity) {
        double d = entity.posX - posX;
        double d1 = entity.posZ - posZ;

			CSM_EntityGravelChunk entitygravelchunk = new CSM_EntityGravelChunk(worldObj, this, clayTeam);
			entitygravelchunk.posY += 0.3999999761581421D;
			double d2 = (entity.posY + (double)entity.getEyeHeight()) - 0.10000000298023224D - entitygravelchunk.posY;
			float f1 = MathHelper.sqrt_double(d * d + d1 * d1) * 0.2F;
			worldObj.spawnEntityInWorld(entitygravelchunk);
			entitygravelchunk.setArrowHeading(d, d2 + (double)f1, d1, 0.6F, 12F);
			attackTime = 30;
			moveForward = -moveForward;

		rotationYaw = (float)((Math.atan2(d1, d) * 180D) / 3.1415927410125732D) - 90F;
		hasAttacked = true;
		swingLeftArm();
    }
	
	public void gotcha(EntityItem item) {
		worldObj.playSoundAtEntity(item, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
		if(item.item != null) {
			item.item.stackSize--;
			if(item.item.stackSize <= 0) {
				item.setEntityDead();
			}
		} else {
			item.setEntityDead();
		}
		targetFollow = null;
		setPathToEntity((PathEntity)null);
	}
	
	public void mountEntity(Entity e) {
		if(!(e != null && e instanceof EntityMinecart)) {
			super.mountEntity(e);
		}
	}
	
	public void gotcha(TileEntityChest chest, int q) {
		worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
		chest.decrStackSize(q, 1);
	}
	
	public void writeToNBT(NBTTagCompound nbttagcompound)
    {
		super.writeToNBT(nbttagcompound);
		nbttagcompound.setShort("ClayTeam", (short)clayTeam);
		nbttagcompound.setShort("WeaponPoints", (short)weaponPoints);
		nbttagcompound.setShort("ArmorPoints", (short)armorPoints);
		nbttagcompound.setShort("FoodLeft", (short)foodLeft);
		nbttagcompound.setShort("SugarTime", (short)sugarTime);
		nbttagcompound.setShort("ResPoints", (short)resPoints);
		nbttagcompound.setShort("GhastTearPts", (short)ghastTearPts);
		nbttagcompound.setShort("StrikeTime", (short)strikeTime);
		nbttagcompound.setShort("ClimbTime", (short)climbTime);
		nbttagcompound.setShort("GooTime", (short)gooTime);
		nbttagcompound.setShort("SmokeTime", (short)smokeTime);
		nbttagcompound.setShort("GooStock", (short)gooStock);
		nbttagcompound.setShort("BlazeStock", (short)blazeStock);
		nbttagcompound.setShort("SmokeStock", (short)smokeStock);
		nbttagcompound.setShort("Logs", (short)logs);
		nbttagcompound.setShort("Rocks", (short)rocks);
		nbttagcompound.setShort("ShieldPts", (short)shieldPts);
		nbttagcompound.setShort("Essence", (short)essence);
		
		nbttagcompound.setBoolean("Gunpowdered", gunpowdered);
		nbttagcompound.setBoolean("KingCrowned", king);
		nbttagcompound.setBoolean("Glowing", glowing);
		nbttagcompound.setBoolean("StickSharp", stickSharp);
		nbttagcompound.setBoolean("hasRod", hasBlazeRod);
		nbttagcompound.setBoolean("ArmorPadded", armorPadded);
		nbttagcompound.setBoolean("HeavyCore", heavyCore);
		nbttagcompound.setBoolean("HasFeather", hasFeather);
		nbttagcompound.setBoolean("FeatherDeployed", featherDeployed);
		nbttagcompound.setBoolean("Goggles", goggles);
		nbttagcompound.setBoolean("SuperSoldier", superSoldier);
		nbttagcompound.setBoolean("Corrupt", corrupt);
		
		nbttagcompound.setInteger("MusicDiscID", MusDiscID); /*ADDED*/
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound)
    {
		super.readFromNBT(nbttagcompound);
		clayTeam = nbttagcompound.getShort("ClayTeam");
		
		texture = clayManTexture(clayTeam);
		weaponPoints = nbttagcompound.getShort("WeaponPoints");
		armorPoints = nbttagcompound.getShort("ArmorPoints");
		foodLeft = nbttagcompound.getShort("FoodLeft");
		sugarTime = nbttagcompound.getShort("SugarTime");
		resPoints = nbttagcompound.getShort("ResPoints");
		ghastTearPts = nbttagcompound.getShort("GhastTearPts");
		strikeTime = nbttagcompound.getShort("StrikeTime");
		climbTime = nbttagcompound.getShort("ClimbTime");
		gooTime = nbttagcompound.getShort("GooTime");
		smokeTime = nbttagcompound.getShort("SmokeTime");
		gooStock = nbttagcompound.getShort("GooStock");
		smokeStock = nbttagcompound.getShort("SmokeStock");
		blazeStock = nbttagcompound.getShort("BlazeStock");
		logs = nbttagcompound.getShort("Logs");
		rocks = nbttagcompound.getShort("Rocks");
		shieldPts = nbttagcompound.getShort("ShieldPts");
		essence = nbttagcompound.getShort("Essence");
		
		gunpowdered = nbttagcompound.getBoolean("Gunpowdered");
		king = nbttagcompound.getBoolean("KingCrowned");
		glowing = nbttagcompound.getBoolean("Glowing");
		stickSharp = nbttagcompound.getBoolean("StickSharp");
		armorPadded = nbttagcompound.getBoolean("ArmorPadded");
		heavyCore = nbttagcompound.getBoolean("HeavyCore");
		hasFeather = nbttagcompound.getBoolean("HasFeather");
		featherDeployed = nbttagcompound.getBoolean("FeatherDeployed");
		goggles = nbttagcompound.getBoolean("Goggles");
		corrupt = nbttagcompound.getBoolean("Corrupt");
		superSoldier = nbttagcompound.getBoolean("SuperSoldier");
		
		if(nbttagcompound.hasKey("hasRod"))
			hasBlazeRod = nbttagcompound.getBoolean("hasRod");
		
		if(nbttagcompound.hasKey("MusicDiscID")) /*ADDED*/
			MusDiscID = nbttagcompound.getInteger("MusicDiscID");
			
	}
	
	protected String getHurtSound()
    {
		if(corrupt) {
			worldObj.playSoundAtEntity(this, "mob.ghast.scream", 0.5F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		} else {
			worldObj.playSoundAtEntity(this, "random.hurt", 0.6F, 1.0F * (rand.nextFloat() * 0.2F + 1.6F));
		}
		worldObj.playSoundAtEntity(this, "step.gravel", 0.6F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		return "";
    }
	
	protected String getDeathSound()
    {
		if(corrupt) {
			worldObj.playSoundAtEntity(this, "mob.ghast.death", 0.5F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
		} else {
			worldObj.playSoundAtEntity(this, "random.hurt", 0.6F, 1.0F * (rand.nextFloat() * 0.2F + 1.6F));
		}
		return "step.gravel";
    }
	
	protected void jump()
    {
		if(gooTime > 0) {
			return;
		}
		if(sugarTime > 0) {
			motionY = 0.375D;
		} else {
			motionY = 0.275D;
		}
    }
	
	public boolean isOnLadder()
    {
		if(logs <= 0 && !featherDeployed && isCollidedHorizontally && climbTime > 0) {
			if(climbTime == 10) {
				if(motionY < 0.05D) {
					climbTime --;
					throwTime = 5;
					return true;
				}
			} else {
				throwTime = 5;
				climbTime --;
				return true;
			}
		}
		return false;
    }
	
	protected boolean canDespawn()
    {
        return false;
    }
	
	public boolean hasStick() {
		return weaponPoints > 0;
	}
	
	public boolean hasArmor() {
		return armorPoints > 0;
	}
	
	public boolean hasSpecks() {
		return gunpowdered;
	}
	
	public boolean hasCrown() {
		return king;
	}
	
	public boolean isGlowing() {
		return glowing;
	}
	
	public boolean isSharpened() {
		return stickSharp;
	}
	
	public boolean isPadded() {
		return armorPadded;
	}
	
	public boolean isGooey() {
		return gooTime > 0;
	}
	
	public boolean hasLogs() {
		return logs > 0;
	}
	
	public boolean holdFeather() {
		return featherDeployed;
	}
	
	public float armLeft() {
		return swingLeft;
	}
	
	public boolean hasBlazeRod() {
		return hasBlazeRod;
	}
	
	public boolean hasRocks() {
		return rocks > 0 && throwTime <= 0 && logs <= 0;
	}
	
	public boolean hasShield() {
		return shieldPts > 0;
	}
	
	public boolean hasGoggles() {
		return goggles;
	}
	
	public boolean isSuper() {
		return superSoldier;
	}
	
	public float capeSwing() {
		if(moveForward > 0F) {
			return (float)Math.sqrt((motionX * motionX) + (motionZ * motionZ)) * 4F;
		} else {
			return 0F;
		}
	}
	
	public boolean isCorrupt() {
		return corrupt;
	}
	
	protected void dropFewItems(boolean flag, int i) {
		if(!gunpowdered) {
			Item item1 = mod_ClayMan.greyDoll;
			dropItem(item1.shiftedIndex, 1, clayTeam);
		
			if(resPoints > 0) {
				dropItem(Item.clay.shiftedIndex, 1);
			}
			
			if(ghastTearPts > 0) {
				dropItem(Item.ghastTear.shiftedIndex, 1);
			}
			
			if(MusDiscID != 0 && hasMusicDisc > 0) {/*ADDED*/
				dropItem(MusDiscID, 1);
				MusDiscID = 0;
				hasMusicDisc = 0;
				worldObj.playRecord(null, MusicCoord[0], MusicCoord[1], MusicCoord[2]);
			}
			
			if(weaponPoints > 7 && rand.nextInt(2) == 0) {
				dropItem(Item.stick.shiftedIndex, 1);
			}
			
			if(hasBlazeRod() && rand.nextInt(2) == 0) {
				dropItem(Item.blazeRod.shiftedIndex, 1);
			}
			
			if(armorPoints > 7 && rand.nextInt(2) == 0) {
				dropItem(Item.leather.shiftedIndex, 1);
			}
			
			if(rocks > 7 && rand.nextInt(2) == 0) {
				dropItem(Block.gravel.blockID, 1);
			}
			
			if(shieldPts > 4 && rand.nextInt(2) == 0) {
				dropItem(Item.bowlEmpty.shiftedIndex, 1);
			}
			
			if(smokeStock > 1 && rand.nextInt(2) == 0) {
				dropItem(Item.redstone.shiftedIndex, 1);
			}
			
			if(blazeStock > 1 && rand.nextInt(2) == 0) {
				dropItem(Item.blazePowder.shiftedIndex, 1);
			}
			
			if(gooStock > 1 && rand.nextInt(2) == 0) {
				dropItem(Item.slimeBall.shiftedIndex, 1);
			}
			
			if(smokeStock > 1 && rand.nextInt(2) == 0) {
				dropItem(Item.redstone.shiftedIndex, 1);
			}
			
			if(gooStock > 1 && rand.nextInt(2) == 0) {
				dropItem(Item.slimeBall.shiftedIndex, 1);
			}
			
			if(glowing && rand.nextInt(2) == 0) {
				dropItem(Item.lightStoneDust.shiftedIndex, 1);
			}
			
			if(king) {
				dropItem(Item.goldNugget.shiftedIndex, 1);
			}
			
			if(heavyCore) {
				dropItem(Item.ingotIron.shiftedIndex, 1);
			}
			
			if(superSoldier) {
				dropItem(Item.diamond.shiftedIndex, 1);
			}
			
			if(hasFeather) {
				dropItem(Item.feather.shiftedIndex, 1);
			}
			
			if(logs > 0) {
				dropLogs();
			}
		}
	}
	
	protected void dropItem(int shiftedIndex, int i, int j) {
		// TODO Auto-generated method stub
		entityDropItem(new ItemStack(shiftedIndex, i, j), 0.0F);
	}
	
	public boolean attackEntityFrom(DamageSource damagesource, int i) {
		Entity e = damagesource.getSourceOfDamage();
		
		if(e instanceof EntityPlayer && !(corrupt && superSoldier)) {
			i = 970;
			hurtTime = 0;
		}
		
		if(e instanceof CSM_EntityGravelChunk) {
			if((((CSM_EntityGravelChunk)e).clayTeam == clayTeam))
				return false;
			else if(shieldPts > 0) {
				if(rand.nextInt(3) == 0) shieldPts--;
				return false;
			}
		}
		
		if(ridingEntity != null && i < 100 && rand.nextInt(2) == 0) {
			return ridingEntity.attackEntityFrom(damagesource, i);
		}
		
		if(damagesource.fireDamage() && !isPotionActive(Potion.fireResistance)) {
			boolean b = super.attackEntityFrom(damagesource, 1);
			if(health <= 0) {
				setEntityDead();
				dropItem(mod_ClayMan.brickDoll.shiftedIndex, 1);
			}
			return b;
		}
	
		boolean corrupted = false;
		if((e == null || !(e instanceof CSM_EntityClayMan)) && !damagesource.fireDamage() && !(e instanceof CSM_EntityGravelChunk)) {
			i += 30;
			
			if(e instanceof EntityFishHook) {
				return false;
			}
		} else if(!damagesource.fireDamage() && !(e instanceof CSM_EntityGravelChunk)) {
			CSM_EntityClayMan james = (CSM_EntityClayMan)e;
			if(corrupt == james.corrupt) {
				if(james.clayTeam != 10 && james.clayTeam == this.clayTeam) {
					return false;
				}
			} else if(james == this && !corrupt) {
				return false;
			}
			
			if(james.heavyCore && ridingEntity != null) {
				mountEntity(ridingEntity);
			}
		
			if(logs > 0) {
				dropLogs();
			}
		
			if(smokeTime <= 0 && clayTeam != 9) {
				entityToAttack = e;
			}
			if(armorPoints > 0) {
				i /= 2;
				if(armorPadded) {
					i -= 1;
				}
				armorPoints --;
				if(i < 0) {
					i = 0;
				}
			}
			
			if(shieldPts > 0) {
				i /= 2;
//				if(armorPadded) {
//					i -= 1;
//				}
				shieldPts --;
				if(i < 0) {
					i = 0;
				}
			}
			
			if(health - i > 0) {
				if((james.smokeStock <= 0 || smokeTime <= 0 || rand.nextInt(2) == 0) && james.gooStock > 0 && gooTime <= 0 && onGround && james.blazeStock <= 0) {
					james.gooStock --;
					gooTime = 150;
					worldObj.playSoundAtEntity(this, "mob.slimeattack", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
					for(int j = 0; j < 4; j++) {
						double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						worldObj.spawnParticle("slime", a, b, c, 0.0D, 0.1D, 0.0D);
					}
					motionX = 0D;
					motionY = 0D;
					motionZ = 0D;
					moveForward = 0F;
					moveStrafing = 0F;
					isJumping = false;
				} else if(james.smokeStock <= 0  && james.gooStock <= 0 && james.blazeStock > 0) {
					james.blazeStock --;
//					worldObj.playSoundAtEntity(this, "random.fizz", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
                    worldObj.playAuxSFXAtEntity(null, 1009, (int)posX, (int)posY, (int)posZ, 0);
					for(int j = 0; j < 4; j++) {
						double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						double b = boundingBox.minY + 0.125D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						worldObj.spawnParticle("reddust", a, b, c, 0.0D, 0.8D, 0.0D);
					}
					if(superSoldier) {
						i = 15;
					} else {
						motionX = 0D;
						motionY = 0D;
						motionZ = 0D;
						moveForward = 0F;
						moveStrafing = 0F;
						isJumping = false;
						setEntityDead();
						dropItem(mod_ClayMan.brickDoll.shiftedIndex, 1);
					}
				} else if(james.smokeStock > 0 && smokeTime <= 0 && blazeStock <= 0) {
					james.smokeStock --;
					smokeTime = 100;
					worldObj.playSoundAtEntity(this, "random.fizz", 0.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
					for(int j = 0; j < 8; j++) {
						double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						double b = boundingBox.minY + 0.25D + (rand.nextFloat() * 0.25D);
						double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
						worldObj.spawnParticle("reddust", a, b, c, 0.0D, 0.1D, 0.0D);
					}
					targetFollow = null;
					entityToAttack = null;
					setPathToEntity((PathEntity)null);
				}
			} else if(james != this && james.corrupt) {
				james.entityToAttack = null;
				james.health = Math.max(james.health, 30);
				james.essence = 3600;
				entityToAttack = null;
				health = Math.max(this.health, 30);
				essence = 3600;
				corrupt = true;
				worldObj.playSoundAtEntity(this, "mob.ghast.scream", 1.75F, 1.0F / (rand.nextFloat() * 0.2F + 0.9F));
				return false;
			}
		}
		
		boolean fred = super.attackEntityFrom(damagesource, i);
		if(fred && health <= 0) {
			victory = 0;
			for(int q = 0; q < 24; q++) {
				double a = posX + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
				double b = posY + 0.25D + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
				double c = posZ + ((rand.nextFloat() - rand.nextFloat()) * 0.125D);
				ModLoader.getMinecraftInstance().effectRenderer.addEffect(new EntityDiggingFX(worldObj, a, b, c, 0.0D, 0.0D, 0.0D, Block.cloth, 0, teamCloth(clayTeam)));
			}
			isDead = true;
			if(e != null && e instanceof EntityPlayer) {
				killedByPlayer = e;
			}
			if(gunpowdered) {
				worldObj.createExplosion(null, posX, posY, posZ, 1F);
			}
		}
		return fred;
	}
	
	public void addVelocity(double d, double d1, double d2)
    {
		if(gooTime > 0) {
			return;
		}
        motionX += d;
        motionY += d1;
        motionZ += d2;
    }
	
	public void knockBack(Entity entity, int i, double d, double d1)
    {
		if(gooTime > 0) {
			return;
		}
        super.knockBack(entity, i, d, d1);
		if(entity != null && entity instanceof CSM_EntityClayMan) {
			CSM_EntityClayMan ec = (CSM_EntityClayMan) entity;
			if((ec.heavyCore && heavyCore) || (!ec.heavyCore && !heavyCore)) {
				motionX *= 0.6D;
				motionY *= 0.75D;
				motionZ *= 0.6D;
			} else if(!ec.heavyCore && heavyCore) {
				motionX *= 0.2D;
				motionY *= 0.4D;
				motionZ *= 0.2D;
			} else {
				motionX *= 1.5D;
				motionZ *= 1.5D;
			}
		} else if(entity != null && entity instanceof CSM_EntityGravelChunk) {
			motionX *= 0.6D;
			motionY *= 0.75D;
			motionZ *= 0.6D;
		}
    }
	
	private void addSquirrelButts() {
		worldObj.spawnParticle("portal", posX + (rand.nextDouble() - 0.5D) * (double)width * 0.5D, (posY + rand.nextDouble() * (double)height) - 0.05D, posZ + (rand.nextDouble() - 0.5D) * (double)width * 0.5D, (rand.nextDouble() - 0.5D) * 0.75D, -rand.nextDouble() * 0.5D, (rand.nextDouble() - 0.5D) * 0.75D);
	}
	
	protected EntityAnimal func_40145_a(EntityAnimal entityanimal) {
		return new EntityPig(worldObj);
	}
	
	public int getMaxHealth() {
		return(clayTeam == 9 ? 15 : (clayTeam == 10 || corrupt) ? 30 : 20) * (superSoldier ? 20 : 1);
	}
	
	public int ghastTearPts/*ADDED*/, blazeStock/*ADDED*/, hasMusicDisc, MusDiscID, clayTeam, weaponPoints, armorPoints, foodLeft, sugarTime, resPoints, entCount, strikeTime, climbTime, gooTime, smokeTime, gooStock, smokeStock, logs, rocks;
	public int shieldPts, blockX, blockY, blockZ, throwTime, essence, victory;
	public float swingLeft;
	public boolean gunpowdered, king, glowing, isSwinging, stickSharp, armorPadded, heavyCore, isSwingingLeft, hasFeather, featherDeployed, goggles, superSoldier, corrupt, hasBlazeRod;
	
	public int[] MusicCoord = new int[3];
	
	public double field_20066_r;
    public double field_20065_s;
    public double field_20064_t;
    public double field_20063_u;
    public double field_20062_v;
    public double field_20061_w;
	
	public Entity targetFollow, killedByPlayer;
}