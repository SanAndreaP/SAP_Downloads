package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class CSM_EntityClayCam extends EntityPlayerSP {
	
	public CSM_EntityClayCam(World world, Minecraft game) {
		super(game, world, game.session, world.worldInfo.getDimension());
		yOffset = -1.2F;
		setSize(0.4F, 0.4F);
		username = "coolie";
		skinUrl = "";
		noClip = true;
	}
	
	public void func_6420_o()
    {
    }
	
	public boolean isSneaking()
    {
        return false;
    }
	
	public CSM_EntityClayCam(World world, EntityLiving entityliving) {
		this(world, ModLoader.getMinecraftInstance());
		entityAnchor = entityliving;
		setPosition(entityAnchor.posX, entityAnchor.posY, entityAnchor.posZ);
	}
	
	public boolean attackEntityFrom(DamageSource damagesource, int i) {
		return false;
	}
	
	protected boolean canDespawn()
    {
        return false;
    }
	
	protected boolean canTriggerWalking()
    {
        return false;
    }
	
	public void onLivingUpdate() {
	}
	
	public void updateEntityActionState() {
	}
	
	public void onUpdate() {
		super.onUpdate();
		if(entityAnchor == null || entityAnchor.isDead || entityAnchor.health <= 0) {
			mod_ClayMan.cameraReset();
			setEntityDead();
		} else {
			Entity jimmy = ModLoader.getMinecraftInstance().renderViewEntity;
			if(jimmy != this) {
				mod_ClayMan.cameraReset();
				setEntityDead();
			} else {
				yOffset = 1.1F;           //rotationYaw
				double angle = entityAnchor.renderYawOffset * gnarliness;
				double d1 = entityAnchor.posX - (Math.sin(angle) * 0.8D);//0.075D
				double d2 = entityAnchor.posZ - (Math.cos(angle) * 0.8D);
				setPosition(d1, entityAnchor.posY + 0.7D, d2);
				// rotationPitch = entityAnchor.rotationPitch;
				// rotationYaw = entityAnchor.rotationYaw;
				faceEntity(entityAnchor, 180F, 180F);
			}
		}
	}
	
	public void addVelocity(double d, double d1, double d2)
    {
    }
	
	public static final double gnarliness = (-3.141593D / 180D);
	
	public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
    }
	
	public EntityLiving entityAnchor;
}