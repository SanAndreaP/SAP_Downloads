package net.minecraft.src;

public class CSM_Purple extends CSM_EntityClayMan{
	public CSM_Purple(World world) {
		super(world, 0D, 0D, 0D, 6);
	}
}