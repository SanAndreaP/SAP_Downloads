package net.minecraft.src;

public class CSM_Green extends CSM_EntityClayMan{
	public CSM_Green(World world) {
		super(world, 0D, 0D, 0D, 3);
	}
}