package net.minecraft.src;

public class CSM_Brown extends CSM_EntityClayMan{
	public CSM_Brown(World world) {
		super(world, 0D, 0D, 0D, 8);
	}
}