package net.minecraft.src;

public class CSM_Pink extends CSM_EntityClayMan{
	public CSM_Pink(World world) {
		super(world, 0D, 0D, 0D, 7);
	}
}