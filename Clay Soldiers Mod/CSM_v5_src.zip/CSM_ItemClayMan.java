package net.minecraft.src;

import java.util.ArrayList;

public class CSM_ItemClayMan extends Item
{

    public CSM_ItemClayMan(int i, int j)
    {
        super(i);
//		clayTeam = j;
		maxStackSize = 16;
		setHasSubtypes(true);
		setMaxDamage(0);
    }

    public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
    {
        if(world.getBlockId(i, j, k) != Block.snow.blockID)
        {
            if(l == 0)
            {
                j--;
            }
            if(l == 1)
            {
                j++;
            }
            if(l == 2)
            {
                k--;
            }
            if(l == 3)
            {
                k++;
            }
            if(l == 4)
            {
                i--;
            }
            if(l == 5)
            {
                i++;
            }
            if(!world.isAirBlock(i, j, k))
            {
                return false;
            }
        }
		boolean jack = false;
		int p = world.getBlockId(i, j, k);
		if(p == 0 || Block.blocksList[p].getCollisionBoundingBoxFromPool(world, i, j, k) == null)
        {
			while(itemstack.stackSize > 0) {
				double a = i + 0.25D + (entityplayer.rand.nextFloat() * 0.5D);
				double b = j + 0.5D;
				double c = k + 0.25D + (entityplayer.rand.nextFloat() * 0.5D);
				CSM_EntityClayMan ec = new CSM_EntityClayMan(world, a, b, c, itemstack.getItemDamage());
				world.spawnEntityInWorld(ec);
				
				jack = true;
				itemstack.stackSize --;
			}
        }
        return jack;
    }

	@Override
	public String getItemNameIS(ItemStack itemstack) {
		switch(itemstack.getItemDamage()) {
			case 0: return "ClaySoldier";
			case 1: return "RedSoldier";
			case 2: return "YellowSoldier";
			case 3: return "GreenSoldier";
			case 4: return "BlueSoldier";
			case 5: return "OrangeSoldier";
			case 6: return "PurpleSoldier";
			case 7: return "PinkSoldier";
			case 8: return "BrownSoldier";
			case 9: return "WhiteSoldier";
			case 10: return "BlackSoldier";
			default: return "ClaySoldier";
		}
	}
	
	public void addCreativeItems(ArrayList itemList) {
		for(int i = 0; i < 11; i++)
			itemList.add(new ItemStack(this, 1, i));
	}
	
	public int getColorFromDamage(int i, int j) {
		if(i == 1) {
			return 0xB24444; //red
		} else if(i == 2) {
			return 0xD2D228; //yellow
		} else if(i == 3) {
			return 0x309630; //green
		} else if(i == 4) {
			return 0x3458A4; //blue
		} else if(i == 5) {
			return 0xE8A033; //orange
		} else if(i == 6) {
			return 0x9044AA; //purple
		} else if(i == 7) {
			return 0xF16878; //pink
		} else if(i == 8) {
			return 0x553322; //brown
		} else if(i == 9) {
			return 0xFFFFFF; //white
		} else if(i == 10) {
			return 0x282828; //black
		}
		
		return 0x808080;
	}
}