package net.minecraft.src;

import org.lwjgl.opengl.GL11;

public class CSM_RenderDirtHorse extends RenderBiped {

    public CSM_RenderDirtHorse(ModelBiped model, float f) {
        super(model, f);
    }
	
	protected void preRenderCallback(EntityLiving entityliving, float f) {
		GL11.glScalef(0.7F, 0.7F, 0.7F);
    }
	
	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		f1 *= 2F;
		super.doRenderLiving(entityliving, d, d1, d2, f, f1);
    } 
}